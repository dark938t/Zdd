"use client";

import React from "react";
import {
  CheckCircle2,
  ShieldAlert,
  Gift,
  XCircle,
  Flame,
  AlertTriangle,
  Activity,
  Zap,
  UserCheck,
} from "lucide-react";
import { CheckStats, ResultStatus } from "@/lib/steam/constants";

interface StatsGridProps {
  stats: CheckStats;
  totalCombos: number;
  activeFilter: string;
  setActiveFilter: (filter: string) => void;
  cpm: number;
  isRunning: boolean;
}

export function StatsGrid({
  stats,
  totalCombos,
  activeFilter,
  setActiveFilter,
  cpm,
  isRunning,
}: StatsGridProps) {
  const percentage = totalCombos > 0 ? Math.min(100, Math.round((stats.done / totalCombos) * 100)) : 0;

  const statCards = [
    {
      id: "hit",
      label: "HITS",
      count: stats.hit,
      color: "text-emerald-400",
      border: "hover:border-emerald-500/50",
      activeBg: "border-emerald-500/60 bg-emerald-950/30",
      glow: stats.hit > 0 ? "shadow-lg shadow-emerald-500/10" : "",
      icon: CheckCircle2,
      desc: "Valid with games/wallet",
    },
    {
      id: "fa",
      label: "FA",
      count: stats.fa,
      color: "text-violet-400",
      border: "hover:border-violet-500/50",
      activeBg: "border-violet-500/60 bg-violet-950/30",
      glow: stats.fa > 0 ? "shadow-lg shadow-violet-500/10" : "",
      icon: UserCheck,
      desc: "First access, nobody else in",
    },
    {
      id: "2fa",
      label: "2FA GUARD",
      count: stats["2fa"],
      color: "text-amber-400",
      border: "hover:border-amber-500/50",
      activeBg: "border-amber-500/60 bg-amber-950/30",
      glow: stats["2fa"] > 0 ? "shadow-lg shadow-amber-500/10" : "",
      icon: ShieldAlert,
      desc: "Mobile / Email Guard",
    },
    {
      id: "free",
      label: "FREE ACCOUNTS",
      count: stats.free,
      color: "text-sky-400",
      border: "hover:border-sky-500/50",
      activeBg: "border-sky-500/60 bg-sky-950/30",
      glow: stats.free > 0 ? "shadow-lg shadow-sky-500/10" : "",
      icon: Gift,
      desc: "Valid credentials, F2P",
    },
    {
      id: "bad",
      label: "BAD",
      count: stats.bad,
      color: "text-rose-400",
      border: "hover:border-rose-500/50",
      activeBg: "border-rose-500/60 bg-rose-950/30",
      glow: "",
      icon: XCircle,
      desc: "Invalid credentials",
    },
    {
      id: "ban",
      label: "BANNED",
      count: stats.ban,
      color: "text-orange-400",
      border: "hover:border-orange-500/50",
      activeBg: "border-orange-500/60 bg-orange-950/30",
      glow: "",
      icon: Flame,
      desc: "Suspended or locked",
    },
    {
      id: "err",
      label: "ERRORS",
      count: stats.err,
      color: "text-slate-400",
      border: "hover:border-slate-500/50",
      activeBg: "border-slate-500/60 bg-slate-900/60",
      glow: "",
      icon: AlertTriangle,
      desc: "Timeout or proxy dead",
    },
  ];

  return (
    <div className="space-y-3">
      {/* Overall Progress Banner */}
      <div className="overflow-hidden rounded-2xl border border-slate-800/80 bg-slate-900/70 p-4 backdrop-blur-md">
        <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <Activity className={`h-4 w-4 ${isRunning ? "animate-pulse text-sky-400" : "text-slate-400"}`} />
            <span className="font-semibold text-slate-200">Checking Progress</span>
            <span className="rounded-full bg-slate-800 px-2 py-0.5 font-mono text-[11px] text-slate-300">
              {stats.done} / {totalCombos} accounts
            </span>
          </div>

          <div className="flex items-center gap-4 text-[11px] text-slate-400">
            <div className="flex items-center gap-1.5">
              <Zap className="h-3 w-3 text-amber-400" />
              <span>Speed:</span>
              <strong className="font-mono text-slate-200">{cpm} CPM</strong>
            </div>
            <div>
              <span>Completed:</span>
              <strong className="ml-1 font-mono text-sky-400">{percentage}%</strong>
            </div>
          </div>
        </div>

        {/* Shimmering Progress Bar */}
        <div className="relative mt-3 h-2.5 w-full overflow-hidden rounded-full bg-slate-800">
          <div
            className="h-full rounded-full bg-gradient-to-r from-sky-500 via-indigo-500 to-emerald-400 transition-all duration-300 ease-out"
            style={{ width: `${percentage}%` }}
          />
          {isRunning && (
            <div className="animate-shimmer absolute inset-0 bg-gradient-to-r from-transparent via-white/25 to-transparent" />
          )}
        </div>
      </div>

      {/* Grid of status cards */}
      <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 xl:grid-cols-7 lg:grid-cols-4">
        {statCards.map((card) => {
          const Icon = card.icon;
          const isSelected = activeFilter === card.id;

          return (
            <button
              key={card.id}
              onClick={() => setActiveFilter(isSelected ? "all" : card.id)}
              className={`group relative flex flex-col justify-between rounded-xl border p-3 text-left transition-all duration-200 ${
                isSelected
                  ? card.activeBg
                  : "border-slate-800/80 bg-slate-900/50 hover:bg-slate-900/80 " + card.border
              } ${card.glow}`}
            >
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold tracking-wider text-slate-400 uppercase group-hover:text-slate-300">
                  {card.label}
                </span>
                <Icon className={`h-4 w-4 ${card.color}`} />
              </div>

              <div className="mt-2">
                <span className={`font-mono text-2xl font-bold tracking-tight ${card.color}`}>
                  {card.count.toLocaleString()}
                </span>
                <p className="mt-0.5 truncate text-[10px] text-slate-400">
                  {card.desc}
                </p>
              </div>

              {isSelected && (
                <div className="absolute inset-x-0 bottom-0 h-0.5 rounded-b-xl bg-current opacity-80" />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
