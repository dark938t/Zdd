"use client";

import React, { useState } from "react";
import {
  X,
  Copy,
  Check,
  ExternalLink,
  Wallet,
  Globe,
  Award,
  Gamepad2,
  ShieldAlert,
  Search,
  Sparkles,
  Users,
  UserCheck,
  AlertTriangle,
} from "lucide-react";
import { ComboResultItem } from "@/lib/steam/constants";
import { soundEngine } from "@/lib/audio";

interface AccountModalProps {
  item: ComboResultItem | null;
  onClose: () => void;
}

export function AccountModal({ item, onClose }: AccountModalProps) {
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [gameSearch, setGameSearch] = useState("");

  if (!item) return null;

  const r = item.result;
  const games = r.game_list || [];
  const filteredGames = games.filter((g) =>
    g.toLowerCase().includes(gameSearch.toLowerCase())
  );

  const copyToClipboard = (text: string, field: string) => {
    soundEngine.playClick();
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const levelNum = parseInt(r.level || "0", 10);
  const levelRingColor =
    levelNum >= 100
      ? "border-purple-500 text-purple-400 bg-purple-950/40"
      : levelNum >= 50
      ? "border-sky-500 text-sky-400 bg-sky-950/40"
      : levelNum >= 25
      ? "border-emerald-500 text-emerald-400 bg-emerald-950/40"
      : levelNum >= 10
      ? "border-amber-500 text-amber-400 bg-amber-950/40"
      : "border-slate-600 text-slate-400 bg-slate-900";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 backdrop-blur-md bg-black/60">
      <div className="relative w-full max-w-2xl overflow-hidden rounded-2xl border border-slate-700/80 bg-slate-900 shadow-2xl shadow-sky-500/10">
        {/* Modal Header Banner */}
        <div className="relative h-28 bg-gradient-to-r from-slate-900 via-sky-950 to-slate-900 p-4">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-sky-500/20 via-transparent to-transparent" />
          
          <button
            onClick={() => {
              soundEngine.playClick();
              onClose();
            }}
            className="absolute top-3 right-3 flex h-8 w-8 items-center justify-center rounded-lg bg-black/40 text-slate-400 backdrop-blur-sm transition hover:bg-black/60 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>

          {/* Status Badge */}
          <div className="relative flex items-center gap-2">
            <span
              className={`rounded-full px-2.5 py-0.5 text-xs font-bold uppercase tracking-wider ${
                r.st === "hit"
                  ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                  : r.st === "2fa"
                  ? "bg-amber-500/20 text-amber-400 border border-amber-500/30"
                  : r.st === "free"
                  ? "bg-sky-500/20 text-sky-400 border border-sky-500/30"
                  : "bg-rose-500/20 text-rose-400 border border-rose-500/30"
              }`}
            >
              [{r.st.toUpperCase()}] ACCOUNT
            </span>
          </div>
        </div>

        {/* Modal Body */}
        <div className="relative px-6 pb-6 pt-0">
          {/* Avatar and Main Identity */}
          <div className="relative -mt-12 flex flex-wrap items-end justify-between gap-4">
            <div className="flex items-end gap-3.5">
              <div className="flex h-20 w-20 items-center justify-center rounded-2xl border-2 border-slate-700 bg-slate-950 p-2 shadow-xl">
                <Gamepad2 className="h-10 w-10 text-sky-400" />
              </div>

              <div>
                <h3 className="text-xl font-bold text-white tracking-tight">
                  {item.username}
                </h3>
                <div className="flex items-center gap-2 text-xs text-slate-400">
                  <span>Combo: {item.combo}</span>
                  <button
                    onClick={() => copyToClipboard(item.combo, "combo")}
                    className="text-slate-400 hover:text-sky-400 transition"
                    title="Copy user:pass"
                  >
                    {copiedField === "combo" ? (
                      <Check className="h-3.5 w-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="h-3.5 w-3.5" />
                    )}
                  </button>
                </div>
              </div>
            </div>

            {/* Quick Profile Link */}
            {r.sid && (
              <a
                href={`https://steamcommunity.com/profiles/${r.sid}`}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800/80 px-3 py-1.5 text-xs font-semibold text-sky-400 transition hover:bg-slate-800 hover:text-sky-300"
              >
                <span>View Community Profile</span>
                <ExternalLink className="h-3.5 w-3.5" />
              </a>
            )}
          </div>

          {/* Quick Metrics Cards */}
          <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
            {/* Level */}
            <div className="flex items-center gap-2.5 rounded-xl border border-slate-800 bg-slate-950/60 p-3">
              <div className={`flex h-10 w-10 items-center justify-center rounded-full border-2 font-mono font-bold text-sm ${levelRingColor}`}>
                {r.level || "0"}
              </div>
              <div>
                <span className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">Level</span>
                <p className="text-xs font-semibold text-slate-200">
                  {levelNum >= 50 ? "High Tier" : levelNum >= 10 ? "Veteran" : "Standard"}
                </p>
              </div>
            </div>

            {/* Wallet */}
            <div className="flex items-center gap-2.5 rounded-xl border border-slate-800 bg-slate-950/60 p-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-500/10 text-emerald-400">
                <Wallet className="h-5 w-5" />
              </div>
              <div>
                <span className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">Wallet</span>
                <p className="text-xs font-semibold text-emerald-400 font-mono">
                  {r.balance || "0.00"}
                </p>
              </div>
            </div>

            {/* Country */}
            <div className="flex items-center gap-2.5 rounded-xl border border-slate-800 bg-slate-950/60 p-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-sky-500/10 text-sky-400">
                <Globe className="h-5 w-5" />
              </div>
              <div>
                <span className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">Region</span>
                <p className="truncate text-xs font-semibold text-slate-200" title={r.country || r.cc || "Unknown"}>
                  {r.country || r.cc || "Global"}
                </p>
              </div>
            </div>

            {/* Games Count */}
            <div className="flex items-center gap-2.5 rounded-xl border border-slate-800 bg-slate-950/60 p-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-500/10 text-indigo-400">
                <Gamepad2 className="h-5 w-5" />
              </div>
              <div>
                <span className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">Games</span>
                <p className="text-xs font-semibold text-indigo-300 font-mono">
                  {r.games || games.length || 0} Owned
                </p>
              </div>
            </div>

            {/* Active Sessions */}
            <div className={`flex items-center gap-2.5 rounded-xl border p-3 ${
              r.fa
                ? "border-violet-500/40 bg-violet-950/20"
                : "border-slate-800 bg-slate-950/60"
            }`}>
              <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${
                r.fa ? "bg-violet-500/15 text-violet-400" : "bg-slate-800 text-slate-400"
              }`}>
                <Users className="h-5 w-5" />
              </div>
              <div>
                <span className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">Active Sessions</span>
                <p className={`text-xs font-semibold font-mono ${
                  r.fa ? "text-violet-300" : "text-slate-300"
                }`}>
                  {r.activeSessions !== undefined ? `${r.activeSessions} online` : "Unknown"}
                  {r.fa && <span className="ml-1.5 rounded bg-violet-500/20 px-1.5 py-0.5 text-[9px] font-bold text-violet-300">FA</span>}
                </p>
              </div>
            </div>
          </div>

          {/* Active session details */}
          {r.sessionDetails && r.sessionDetails.length > 0 && (
            <div className="mt-4 rounded-xl border border-slate-800 bg-slate-950/60 p-3.5">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-300 mb-2">
                <Users className="h-4 w-4 text-sky-400" />
                <span>Who is using this account</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {r.sessionDetails.map((detail, i) => (
                  <span
                    key={i}
                    className="inline-flex items-center rounded-md border border-slate-800 bg-slate-900 px-2.5 py-1 text-xs text-slate-200"
                  >
                    {detail}
                  </span>
                ))}
              </div>
              {r.fa ? (
                <p className="mt-2 flex items-center gap-1.5 text-xs text-violet-300">
                  <UserCheck className="h-3.5 w-3.5" />
                  <span>Only this session is active — the account is free to use (FA).</span>
                </p>
              ) : (
                <p className="mt-2 flex items-center gap-1.5 text-xs text-amber-300">
                  <AlertTriangle className="h-3.5 w-3.5" />
                  <span>Other sessions are active — someone else may be using this account.</span>
                </p>
              )}
            </div>
          )}

          {/* SteamID and Security Details */}
          <div className="mt-4 rounded-xl border border-slate-800 bg-slate-950/60 p-3.5 space-y-2 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">SteamID64:</span>
              <div className="flex items-center gap-2 font-mono text-slate-200">
                <span>{r.sid || "N/A"}</span>
                {r.sid && (
                  <button
                    onClick={() => copyToClipboard(r.sid!, "sid")}
                    className="text-slate-400 hover:text-sky-400"
                  >
                    {copiedField === "sid" ? (
                      <Check className="h-3.5 w-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="h-3.5 w-3.5" />
                    )}
                  </button>
                )}
              </div>
            </div>

            {r.types && (
              <div className="flex items-center justify-between border-t border-slate-800/80 pt-2">
                <span className="text-slate-400">2FA Type:</span>
                <span className="font-mono text-amber-400">{r.types}</span>
              </div>
            )}

            {r.info && (
              <div className="flex items-center justify-between border-t border-slate-800/80 pt-2">
                <span className="text-slate-400">Detail / Note:</span>
                <span className="text-slate-300">{r.info}</span>
              </div>
            )}
          </div>

          {/* Games Library section */}
          <div className="mt-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-300">
                <Gamepad2 className="h-4 w-4 text-sky-400" />
                <span>Games Library ({games.length})</span>
              </div>

              {games.length > 5 && (
                <div className="relative w-44">
                  <Search className="absolute left-2.5 top-2 h-3.5 w-3.5 text-slate-500" />
                  <input
                    type="text"
                    value={gameSearch}
                    onChange={(e) => setGameSearch(e.target.value)}
                    placeholder="Search games..."
                    className="w-full rounded-lg border border-slate-800 bg-slate-950 py-1 pl-8 pr-2 text-xs text-slate-200 placeholder-slate-500 focus:border-sky-500 focus:outline-none"
                  />
                </div>
              )}
            </div>

            {games.length === 0 ? (
              <div className="rounded-xl border border-dashed border-slate-800 p-4 text-center text-xs text-slate-500">
                No owned games detected or private games library
              </div>
            ) : (
              <div className="max-h-44 overflow-y-auto rounded-xl border border-slate-800 bg-slate-950/70 p-2.5">
                <div className="flex flex-wrap gap-1.5">
                  {filteredGames.map((game, idx) => (
                    <span
                      key={idx}
                      className="inline-flex items-center rounded-md border border-slate-800 bg-slate-900 px-2.5 py-1 text-xs text-slate-200 hover:border-slate-700"
                    >
                      {game}
                    </span>
                  ))}
                  {filteredGames.length === 0 && (
                    <span className="text-xs text-slate-500">No games match &quot;{gameSearch}&quot;</span>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Action Footer */}
          <div className="mt-5 flex items-center justify-end gap-2 border-t border-slate-800/80 pt-4">
            <button
              onClick={() => {
                const games = (r.game_list || []).join(", ") || "None";
                const summary = `[${r.st.toUpperCase()}] ${item.combo} | SteamID: ${r.sid || "N/A"} | Level: ${r.level || "0"} | Games: ${r.games || 0} | Wallet: ${r.balance || "0"} | Country: ${r.country || "N/A"}\n  Games: ${games}`;
                copyToClipboard(summary, "summary");
              }}
              className="flex items-center gap-1.5 rounded-xl border border-slate-700 bg-slate-800 px-3.5 py-2 text-xs font-semibold text-slate-200 transition hover:bg-slate-700"
            >
              {copiedField === "summary" ? (
                <>
                  <Check className="h-3.5 w-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Copied Summary!</span>
                </>
              ) : (
                <>
                  <Copy className="h-3.5 w-3.5" />
                  <span>Copy Summary</span>
                </>
              )}
            </button>

            <button
              onClick={() => {
                soundEngine.playClick();
                onClose();
              }}
              className="rounded-xl bg-sky-500 px-4 py-2 text-xs font-bold text-white transition hover:bg-sky-400"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
