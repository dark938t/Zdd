"use client";

import React, { useState, useEffect, useRef } from "react";
import {
  Search,
  Filter,
  Eye,
  Copy,
  Check,
  ExternalLink,
  Gamepad2,
  Wallet,
  Globe,
  Terminal,
  LayoutGrid,
  Download,
  Trash2,
  ShieldAlert,
  Flame,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  ArrowDownToLine,
  UserCheck,
  Users,
} from "lucide-react";
import { ComboResultItem, ResultStatus } from "@/lib/steam/constants";
import { soundEngine } from "@/lib/audio";

interface ResultsViewProps {
  results: ComboResultItem[];
  activeFilter: string;
  setActiveFilter: (filter: string) => void;
  onInspect: (item: ComboResultItem) => void;
  onClear: () => void;
  onExportTxt: () => void;
  onExportJson: () => void;
  onExportCsv: () => void;
  onCopyAllHits: () => void;
  copiedHitsNotice: boolean;
  isRunning: boolean;
}

export function ResultsView({
  results,
  activeFilter,
  setActiveFilter,
  onInspect,
  onClear,
  onExportTxt,
  onExportJson,
  onExportCsv,
  onCopyAllHits,
  copiedHitsNotice,
  isRunning,
}: ResultsViewProps) {
  const [viewMode, setViewMode] = useState<"cards" | "terminal">("cards");
  const [searchQuery, setSearchQuery] = useState("");
  const [autoScroll, setAutoScroll] = useState(true);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const terminalEndRef = useRef<HTMLDivElement | null>(null);

  // Auto-scroll to bottom of terminal if enabled
  useEffect(() => {
    if (autoScroll && terminalEndRef.current && isRunning) {
      terminalEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [results, autoScroll, isRunning]);

  const copyCombo = (combo: string, id: string) => {
    soundEngine.playClick();
    navigator.clipboard.writeText(combo);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  // Filter items
  const filteredResults = results.filter((item) => {
    const r = item.result;
    let matchesFilter = activeFilter === "all" || r.st === activeFilter;
    if (activeFilter === "fa") {
      matchesFilter = r.st === "hit" && r.fa === true;
    }
    if (!matchesFilter) return false;

    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();

    return (
      item.combo.toLowerCase().includes(q) ||
      item.username.toLowerCase().includes(q) ||
      (r.sid && r.sid.toLowerCase().includes(q)) ||
      (r.country && r.country.toLowerCase().includes(q)) ||
      (r.cc && r.cc.toLowerCase().includes(q)) ||
      (r.balance && r.balance.toLowerCase().includes(q)) ||
      (r.game_list && r.game_list.some((g) => g.toLowerCase().includes(q)))
    );
  });

  const counts: Record<string, number> = {
    all: results.length,
    hit: results.filter((r) => r.result.st === "hit").length,
    fa: results.filter((r) => r.result.st === "hit" && r.result.fa).length,
    "2fa": results.filter((r) => r.result.st === "2fa").length,
    free: results.filter((r) => r.result.st === "free").length,
    bad: results.filter((r) => r.result.st === "bad").length,
    ban: results.filter((r) => r.result.st === "ban").length,
    err: results.filter((r) => r.result.st === "err").length,
  };

  const getStatusBadge = (st: ResultStatus) => {
    switch (st) {
      case "hit":
        return {
          label: "HIT",
          className: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30",
          icon: CheckCircle2,
        };
      case "2fa":
        return {
          label: "2FA",
          className: "bg-amber-500/15 text-amber-400 border-amber-500/30",
          icon: ShieldAlert,
        };
      case "free":
        return {
          label: "FREE",
          className: "bg-sky-500/15 text-sky-400 border-sky-500/30",
          icon: Gamepad2,
        };
      case "bad":
        return {
          label: "BAD",
          className: "bg-rose-500/15 text-rose-400 border-rose-500/30",
          icon: XCircle,
        };
      case "ban":
        return {
          label: "BAN",
          className: "bg-orange-500/15 text-orange-400 border-orange-500/30",
          icon: Flame,
        };
      case "err":
      default:
        return {
          label: "ERR",
          className: "bg-slate-500/15 text-slate-400 border-slate-500/30",
          icon: AlertTriangle,
        };
    }
  };

  return (
    <div className="rounded-2xl border border-slate-800/80 bg-slate-900/60 p-4 backdrop-blur-md">
      {/* Top Controls Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
        {/* Left: Filter Tabs */}
        <div className="flex flex-wrap items-center gap-1.5 text-xs">
          {[
            { id: "all", label: "All" },
            { id: "hit", label: "Hits", color: "text-emerald-400" },
            { id: "fa", label: "FA", color: "text-violet-400" },
            { id: "2fa", label: "2FA", color: "text-amber-400" },
            { id: "free", label: "Free", color: "text-sky-400" },
            { id: "bad", label: "Bad", color: "text-rose-400" },
            { id: "ban", label: "Ban", color: "text-orange-400" },
            { id: "err", label: "Errors", color: "text-slate-400" },
          ].map((tab) => {
            const isActive = activeFilter === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  soundEngine.playClick();
                  setActiveFilter(tab.id);
                }}
                className={`flex items-center gap-1.5 rounded-lg px-2.5 py-1 font-medium transition ${
                  isActive
                    ? "bg-slate-800 text-white shadow-sm border border-slate-700"
                    : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/50"
                }`}
              >
                <span>{tab.label}</span>
                <span
                  className={`rounded-full px-1.5 py-0.2 text-[10px] font-mono font-bold ${
                    isActive ? "bg-slate-700 text-white" : "bg-slate-950 text-slate-400"
                  }`}
                >
                  {counts[tab.id] || 0}
                </span>
              </button>
            );
          })}
        </div>

        {/* Right: Search + View Mode + Actions */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Search bar */}
          <div className="relative">
            <Search className="absolute left-2.5 top-2 h-3.5 w-3.5 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter by user, game, ID..."
              className="w-48 rounded-lg border border-slate-800 bg-slate-950 py-1.5 pl-8 pr-2.5 text-xs text-slate-200 placeholder-slate-500 focus:border-sky-500 focus:outline-none"
            />
          </div>

          {/* View Mode Toggle */}
          <div className="flex items-center rounded-lg border border-slate-800 bg-slate-950 p-0.5">
            <button
              onClick={() => {
                soundEngine.playClick();
                setViewMode("cards");
              }}
              title="Card Grid View"
              className={`rounded-md p-1.5 transition ${
                viewMode === "cards" ? "bg-slate-800 text-sky-400" : "text-slate-400 hover:text-slate-200"
              }`}
            >
              <LayoutGrid className="h-3.5 w-3.5" />
            </button>
            <button
              onClick={() => {
                soundEngine.playClick();
                setViewMode("terminal");
              }}
              title="Terminal Stream View"
              className={`rounded-md p-1.5 transition ${
                viewMode === "terminal" ? "bg-slate-800 text-sky-400" : "text-slate-400 hover:text-slate-200"
              }`}
            >
              <Terminal className="h-3.5 w-3.5" />
            </button>
          </div>

          {/* Export Dropdown / Actions */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={onCopyAllHits}
              title="Copy all Hits to clipboard"
              className="flex items-center gap-1 rounded-lg border border-emerald-500/30 bg-emerald-950/40 px-2.5 py-1.5 text-xs font-semibold text-emerald-400 transition hover:bg-emerald-900/50"
            >
              {copiedHitsNotice ? (
                <>
                  <Check className="h-3.5 w-3.5" />
                  <span>Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="h-3.5 w-3.5" />
                  <span>Copy Hits ({counts.hit})</span>
                </>
              )}
            </button>

            <button
              onClick={onExportTxt}
              title="Export as Text file"
              className="flex items-center gap-1 rounded-lg border border-slate-800 bg-slate-950 px-2.5 py-1.5 text-xs font-semibold text-slate-300 transition hover:bg-slate-800"
            >
              <Download className="h-3.5 w-3.5 text-sky-400" />
              <span>.TXT</span>
            </button>

            <button
              onClick={onExportJson}
              title="Export as JSON"
              className="flex items-center gap-1 rounded-lg border border-slate-800 bg-slate-950 px-2.5 py-1.5 text-xs font-semibold text-slate-300 transition hover:bg-slate-800"
            >
              <Download className="h-3.5 w-3.5 text-indigo-400" />
              <span>.JSON</span>
            </button>

            <button
              onClick={onClear}
              title="Clear all results"
              className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-800 bg-slate-950 text-slate-400 transition hover:border-rose-900 hover:bg-rose-950/30 hover:text-rose-400"
            >
              <Trash2 className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Results Content */}
      <div className="mt-3">
        {filteredResults.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-slate-800 bg-slate-950 text-slate-600">
              <Terminal className="h-6 w-6" />
            </div>
            <p className="mt-3 text-sm font-semibold text-slate-300">
              {results.length === 0
                ? "Ready to inspect. Paste credentials above and start."
                : "No results match current filter or search criteria."}
            </p>
            <p className="mt-1 text-xs text-slate-500">
              {results.length === 0
                ? "Live feed and captured Steam profiles will display here in real time."
                : "Try selecting 'All' or clearing your search query."}
            </p>
          </div>
        ) : viewMode === "cards" ? (
          /* Cards Grid View */
          <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
            {filteredResults.map((item) => {
              const r = item.result;
              const badge = getStatusBadge(r.st);
              const BadgeIcon = badge.icon;
              const isHit = r.st === "hit";
              const is2fa = r.st === "2fa";
              const isFree = r.st === "free";

              return (
                <div
                  key={item.id}
                  className={`group relative flex flex-col justify-between rounded-xl border p-3.5 transition-all duration-200 ${
                    isHit
                      ? "border-emerald-500/30 bg-slate-950/80 hover:border-emerald-500/60 shadow-lg shadow-emerald-500/5"
                      : is2fa
                      ? "border-amber-500/30 bg-slate-950/80 hover:border-amber-500/60"
                      : isFree
                      ? "border-sky-500/30 bg-slate-950/80 hover:border-sky-500/60"
                      : "border-slate-800/80 bg-slate-950/50 opacity-80 hover:opacity-100"
                  }`}
                >
                  {/* Card Header */}
                  <div>
                    <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5">
                      <span
                        className={`inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider ${badge.className}`}
                      >
                        <BadgeIcon className="h-3 w-3" />
                        <span>{badge.label}</span>
                      </span>

                      {isHit && r.fa && (
                        <span
                          className="inline-flex items-center gap-1 rounded-md border border-violet-500/40 bg-violet-500/15 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-violet-300"
                          title="First Access — nobody else is using this account"
                        >
                          <UserCheck className="h-3 w-3" />
                          <span>FA</span>
                        </span>
                      )}

                      {isHit && r.activeSessions !== undefined && (
                        <span
                          className="inline-flex items-center gap-1 rounded-md border border-slate-700 bg-slate-900 px-2 py-0.5 text-[10px] font-mono text-slate-300"
                          title="Active sessions currently using the account"
                        >
                          <Users className="h-3 w-3 text-sky-400" />
                          <span>{r.activeSessions}</span>
                        </span>
                      )}

                      {r.level && (
                          <span className="rounded-md border border-slate-800 bg-slate-900 px-1.5 py-0.5 text-[10px] font-mono font-bold text-slate-300">
                            Lv.{r.level}
                          </span>
                        )}
                      </div>

                      {/* Action buttons */}
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => copyCombo(item.combo, item.id)}
                          title="Copy user:pass"
                          className="rounded-md p-1 text-slate-400 transition hover:bg-slate-800 hover:text-slate-200"
                        >
                          {copiedId === item.id ? (
                            <Check className="h-3.5 w-3.5 text-emerald-400" />
                          ) : (
                            <Copy className="h-3.5 w-3.5" />
                          )}
                        </button>

                        {(isHit || is2fa || isFree) && (
                          <button
                            onClick={() => {
                              soundEngine.playClick();
                              onInspect(item);
                            }}
                            title="Inspect Steam Account"
                            className="rounded-md p-1 text-sky-400 transition hover:bg-sky-500/20"
                          >
                            <Eye className="h-3.5 w-3.5" />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Account combo */}
                    <div className="mt-2.5">
                      <h4 className="truncate font-mono text-xs font-bold text-slate-100" title={item.combo}>
                        {item.username}
                      </h4>
                      <p className="truncate font-mono text-[11px] text-slate-400">
                        {item.combo}
                      </p>
                    </div>

                    {/* Details pill row */}
                    {(isHit || isFree || is2fa) && (
                      <div className="mt-3 flex flex-wrap items-center gap-1.5 text-[11px]">
                        {r.balance && (
                          <span className="flex items-center gap-1 rounded border border-emerald-500/20 bg-emerald-950/30 px-1.5 py-0.5 font-mono text-emerald-400">
                            <Wallet className="h-3 w-3" />
                            <span>{r.balance}</span>
                          </span>
                        )}

                        {(r.country || r.cc) && (
                          <span className="flex items-center gap-1 rounded border border-slate-800 bg-slate-900 px-1.5 py-0.5 text-slate-300">
                            <Globe className="h-3 w-3 text-sky-400" />
                            <span>{r.cc || r.country}</span>
                          </span>
                        )}

                        {r.games !== undefined && r.games > 0 && (
                          <span className="flex items-center gap-1 rounded border border-indigo-500/20 bg-indigo-950/30 px-1.5 py-0.5 text-indigo-300">
                            <Gamepad2 className="h-3 w-3" />
                            <span>{r.games} games</span>
                          </span>
                        )}
                      </div>
                    )}

                    {/* Sample Games preview */}
                    {r.game_list && r.game_list.length > 0 && (
                      <div className="mt-2 flex flex-wrap gap-1">
                        {r.game_list.slice(0, 3).map((g, i) => (
                          <span
                            key={i}
                            className="truncate max-w-[130px] rounded bg-slate-900 px-1.5 py-0.5 text-[10px] text-slate-400"
                            title={g}
                          >
                            {g}
                          </span>
                        ))}
                        {r.game_list.length > 3 && (
                          <span className="rounded bg-slate-900 px-1.5 py-0.5 text-[10px] text-slate-400 font-mono">
                            +{r.game_list.length - 3}
                          </span>
                        )}
                      </div>
                    )}

                    {r.info && (
                      <p className="mt-2 text-[11px] text-slate-400 truncate">
                        {r.info}
                      </p>
                    )}
                  </div>

                  {/* Card footer */}
                  <div className="mt-3 flex items-center justify-between border-t border-slate-800/80 pt-2 text-[10px] text-slate-400">
                    <span className="font-mono">
                      {r.sid ? `ID: ${r.sid}` : "Checked"}
                    </span>
                    {(isHit || is2fa || isFree) && (
                      <button
                        onClick={() => {
                          soundEngine.playClick();
                          onInspect(item);
                        }}
                        className="font-semibold text-sky-400 hover:underline"
                      >
                        Inspect Details &rarr;
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          /* Terminal Stream View */
          <div className="relative max-h-[460px] overflow-y-auto rounded-xl border border-slate-800 bg-slate-950 p-3 font-mono text-xs">
            <div className="space-y-1.5">
              {filteredResults.map((item) => {
                const r = item.result;
                const badge = getStatusBadge(r.st);

                return (
                  <div
                    key={item.id}
                    className="flex flex-wrap items-start justify-between gap-2 rounded border border-slate-900 bg-slate-900/40 px-2 py-1.5 hover:border-slate-800 transition"
                  >
                    <div className="flex flex-wrap items-center gap-2">
                      <span
                        className={`inline-block rounded px-1.5 py-0.2 font-bold ${
                          r.st === "hit"
                            ? "bg-emerald-500/20 text-emerald-400"
                            : r.st === "2fa"
                            ? "bg-amber-500/20 text-amber-400"
                            : r.st === "free"
                            ? "bg-sky-500/20 text-sky-400"
                            : r.st === "bad"
                            ? "bg-rose-500/20 text-rose-400"
                            : r.st === "ban"
                            ? "bg-orange-500/20 text-orange-400"
                            : "bg-slate-700 text-slate-300"
                        }`}
                      >
                        [{badge.label}]
                      </span>
                      <span className="text-slate-200">{item.combo}</span>
                      {r.sid && (
                        <span className="text-slate-400">| ID:{r.sid}</span>
                      )}
                      {r.level && (
                        <span className="text-amber-400">| Lv:{r.level}</span>
                      )}
                      {r.games !== undefined && r.games > 0 && (
                        <span className="text-indigo-400">| Games:{r.games}</span>
                      )}
                      {r.balance && (
                        <span className="text-emerald-400">| Wallet:{r.balance}</span>
                      )}
                      {r.country && (
                        <span className="text-sky-400">| {r.country}</span>
                      )}
                      {r.activeSessions !== undefined && (
                        <span className="text-slate-400">| Sessions:{r.activeSessions}</span>
                      )}
                      {r.fa && (
                        <span className="text-violet-400">| FA</span>
                      )}
                      {r.info && (
                        <span className="text-slate-400">| {r.info}</span>
                      )}
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        onClick={() => copyCombo(item.combo, item.id)}
                        className="text-slate-400 hover:text-slate-200"
                        title="Copy combo"
                      >
                        {copiedId === item.id ? (
                          <Check className="h-3 w-3 text-emerald-400" />
                        ) : (
                          <Copy className="h-3 w-3" />
                        )}
                      </button>

                      {(r.st === "hit" || r.st === "free" || r.st === "2fa") && (
                        <button
                          onClick={() => {
                            soundEngine.playClick();
                            onInspect(item);
                          }}
                          className="text-sky-400 hover:text-sky-300"
                          title="Inspect account"
                        >
                          <Eye className="h-3 w-3" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
              <div ref={terminalEndRef} />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
