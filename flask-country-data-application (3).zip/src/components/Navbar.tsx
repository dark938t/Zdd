"use client";

import React from "react";
import {
  Gamepad2,
  Volume2,
  VolumeX,
  Sparkles,
  Database,
  Wrench,
  Network,
  Cpu,
  Layers,
} from "lucide-react";
import { soundEngine } from "@/lib/audio";

interface NavbarProps {
  activeTab: "checker" | "vault" | "tools" | "proxies";
  setActiveTab: (tab: "checker" | "vault" | "tools" | "proxies") => void;
  demoMode: boolean;
  setDemoMode: (val: boolean) => void;
  isMuted: boolean;
  setIsMuted: (val: boolean) => void;
  isRunning: boolean;
}

export function Navbar({
  activeTab,
  setActiveTab,
  demoMode,
  setDemoMode,
  isMuted,
  setIsMuted,
  isRunning,
}: NavbarProps) {
  const toggleMute = () => {
    soundEngine.muted = !isMuted;
    setIsMuted(!isMuted);
    if (isMuted) {
      soundEngine.playClick();
    }
  };

  return (
    <header className="sticky top-0 z-40 border-b border-slate-800/80 bg-slate-950/80 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-4 py-3 sm:px-6">
        {/* Logo and branding */}
        <div className="flex items-center gap-3">
          <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-blue-600 via-sky-500 to-emerald-400 p-0.5 shadow-lg shadow-sky-500/20">
            <div className="flex h-full w-full items-center justify-center rounded-[10px] bg-slate-950">
              <Gamepad2 className="h-5 w-5 text-sky-400" />
            </div>
            {isRunning && (
              <span className="absolute -top-1 -right-1 flex h-3 w-3">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex h-3 w-3 rounded-full bg-emerald-500"></span>
              </span>
            )}
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-bold tracking-tight text-white sm:text-xl">
                STEAM<span className="text-sky-400">ENGINE</span>
              </h1>
              <span className="rounded border border-sky-500/30 bg-sky-500/10 px-1.5 py-0.5 text-[10px] font-semibold text-sky-400 uppercase tracking-wider">
                v1.5 PRO
              </span>
            </div>
            <p className="text-xs text-slate-400">
              High-Speed Mobile Auth & Account Inspector
            </p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 rounded-xl border border-slate-800 bg-slate-900/90 p-1">
          <button
            onClick={() => {
              soundEngine.playClick();
              setActiveTab("checker");
            }}
            className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-all ${
              activeTab === "checker"
                ? "bg-sky-500 text-white shadow-md shadow-sky-500/25"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            <Cpu className="h-3.5 w-3.5" />
            <span>Checker</span>
          </button>

          <button
            onClick={() => {
              soundEngine.playClick();
              setActiveTab("vault");
            }}
            className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-all ${
              activeTab === "vault"
                ? "bg-sky-500 text-white shadow-md shadow-sky-500/25"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            <Database className="h-3.5 w-3.5" />
            <span>Hits Vault</span>
          </button>

          <button
            onClick={() => {
              soundEngine.playClick();
              setActiveTab("tools");
            }}
            className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-all ${
              activeTab === "tools"
                ? "bg-sky-500 text-white shadow-md shadow-sky-500/25"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            <Wrench className="h-3.5 w-3.5" />
            <span>Combo Tools</span>
          </button>

          <button
            onClick={() => {
              soundEngine.playClick();
              setActiveTab("proxies");
            }}
            className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-all ${
              activeTab === "proxies"
                ? "bg-sky-500 text-white shadow-md shadow-sky-500/25"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            <Network className="h-3.5 w-3.5" />
            <span>Proxy Tester</span>
          </button>
        </div>

        {/* Global Controls: Demo Switch, Sound Toggle */}
        <div className="flex items-center gap-2">
          {/* Demo Mode Toggle */}
          <div className="flex items-center gap-2 rounded-xl border border-slate-800 bg-slate-900/80 px-3 py-1.5">
            <div className="flex flex-col text-right">
              <span className="text-[11px] font-medium text-slate-300">
                {demoMode ? "UI Preview" : "Live Steam"}
              </span>
              <span className="text-[9px] text-slate-500">
                {demoMode ? "Sample data only" : "Real API checks"}
              </span>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={demoMode}
              onClick={() => {
                soundEngine.playClick();
                setDemoMode(!demoMode);
              }}
              className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                demoMode ? "bg-emerald-500" : "bg-slate-700"
              }`}
            >
              <span
                className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                  demoMode ? "translate-x-4" : "translate-x-0"
                }`}
              />
            </button>
          </div>

          {/* Audio toggle button */}
          <button
            type="button"
            onClick={toggleMute}
            title={isMuted ? "Unmute audio effects" : "Mute audio effects"}
            className="flex h-9 w-9 items-center justify-center rounded-xl border border-slate-800 bg-slate-900/80 text-slate-400 transition hover:border-slate-700 hover:text-slate-200"
          >
            {isMuted ? (
              <VolumeX className="h-4 w-4 text-slate-500" />
            ) : (
              <Volume2 className="h-4 w-4 text-emerald-400" />
            )}
          </button>
        </div>
      </div>
    </header>
  );
}
