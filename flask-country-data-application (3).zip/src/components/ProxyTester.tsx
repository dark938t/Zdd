"use client";

import React, { useState } from "react";
import {
  Network,
  Play,
  RotateCcw,
  CheckCircle2,
  XCircle,
  Clock,
  ArrowRight,
  ShieldCheck,
  AlertCircle,
} from "lucide-react";
import { soundEngine } from "@/lib/audio";

interface ProxyTestResult {
  proxy: string;
  alive: boolean;
  status?: number;
  latency: number;
  error?: string;
}

interface ProxyTesterProps {
  initialProxies: string;
  onApplyProxies: (proxiesText: string) => void;
}

export function ProxyTester({ initialProxies, onApplyProxies }: ProxyTesterProps) {
  const [proxyInput, setProxyInput] = useState(initialProxies || "");
  const [testing, setTesting] = useState(false);
  const [results, setResults] = useState<ProxyTestResult[]>([]);
  const [errorMsg, setErrorMsg] = useState("");

  const runTest = async () => {
    soundEngine.playClick();
    const list = proxyInput
      .split("\n")
      .map((x) => x.trim())
      .filter(Boolean);

    if (list.length === 0) {
      setErrorMsg("Please enter at least one proxy to test");
      return;
    }

    setErrorMsg("");
    setTesting(true);
    setResults([]);

    try {
      const res = await fetch("/api/proxy-test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ proxies: list.slice(0, 20) }),
      });
      const data = await res.json();
      if (data.results) {
        setResults(data.results);
      }
    } catch (err: any) {
      setErrorMsg(err?.message || "Proxy test request failed");
    } finally {
      setTesting(false);
    }
  };

  const applyAliveOnly = () => {
    soundEngine.playClick();
    const aliveProxies = results.filter((r) => r.alive).map((r) => r.proxy);
    if (aliveProxies.length > 0) {
      onApplyProxies(aliveProxies.join("\n"));
    }
  };

  const aliveCount = results.filter((r) => r.alive).length;

  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-slate-800/80 bg-slate-900/60 p-5 backdrop-blur-md">
        <div className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-sky-500/10 text-sky-400">
            <Network className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white">Proxy Latency & Health Inspector</h2>
            <p className="text-xs text-slate-400">
              Test HTTP/HTTPS & SOCKS proxies against Steam Web APIs to verify speed and reachability
            </p>
          </div>
        </div>

        <div className="mt-5 grid grid-cols-1 gap-5 lg:grid-cols-2">
          {/* Input list */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-2">
              Proxies to Test <span className="text-slate-500 font-normal">(one per line)</span>
            </label>
            <textarea
              rows={9}
              value={proxyInput}
              onChange={(e) => setProxyInput(e.target.value)}
              placeholder={`127.0.0.1:8080\nhttp://user:pass@1.2.3.4:3128\nsocks5://127.0.0.1:1080`}
              className="w-full rounded-xl border border-slate-800 bg-slate-950 p-3 font-mono text-xs text-slate-200 placeholder-slate-600 focus:border-sky-500 focus:outline-none"
            />
            <div className="mt-3 flex items-center gap-2">
              <button
                onClick={runTest}
                disabled={testing}
                className="flex items-center gap-1.5 rounded-xl bg-sky-500 px-4 py-2 text-xs font-bold text-white shadow-md shadow-sky-500/20 transition hover:bg-sky-400 disabled:opacity-40"
              >
                {testing ? (
                  <>
                    <RotateCcw className="h-3.5 w-3.5 animate-spin" />
                    <span>Testing Network...</span>
                  </>
                ) : (
                  <>
                    <Play className="h-3.5 w-3.5" />
                    <span>Test Proxies</span>
                  </>
                )}
              </button>

              <button
                onClick={() => {
                  setProxyInput("");
                  setResults([]);
                }}
                className="rounded-xl border border-slate-800 bg-slate-950 px-3.5 py-2 text-xs text-slate-400 transition hover:text-slate-200"
              >
                Clear
              </button>
            </div>
            {errorMsg && (
              <p className="mt-2 text-xs text-rose-400 flex items-center gap-1">
                <AlertCircle className="h-3.5 w-3.5" />
                {errorMsg}
              </p>
            )}
          </div>

          {/* Results column */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-300">
                Diagnostic Results ({results.length})
              </span>
              {aliveCount > 0 && (
                <button
                  onClick={applyAliveOnly}
                  className="flex items-center gap-1 text-xs font-bold text-emerald-400 hover:underline"
                >
                  <span>Apply {aliveCount} Alive to Checker</span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </button>
              )}
            </div>

            {results.length === 0 ? (
              <div className="flex h-56 flex-col items-center justify-center rounded-xl border border-dashed border-slate-800 bg-slate-950/40 p-4 text-center text-xs text-slate-500">
                <ShieldCheck className="h-8 w-8 text-slate-700 mb-2" />
                <span>Enter proxy lines and click &quot;Test Proxies&quot; to inspect response times.</span>
              </div>
            ) : (
              <div className="max-h-60 overflow-y-auto space-y-1.5 rounded-xl border border-slate-800 bg-slate-950 p-2 text-xs font-mono">
                {results.map((res, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between rounded border border-slate-900 bg-slate-900/60 p-2"
                  >
                    <div className="flex items-center gap-2 truncate">
                      {res.alive ? (
                        <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" />
                      ) : (
                        <XCircle className="h-4 w-4 shrink-0 text-rose-400" />
                      )}
                      <span className="text-slate-200 truncate">{res.proxy}</span>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <span className="flex items-center gap-1 text-[11px] text-slate-400">
                        <Clock className="h-3 w-3" />
                        {res.latency}ms
                      </span>
                      <span
                        className={`rounded px-1.5 py-0.5 text-[10px] font-bold ${
                          res.alive
                            ? "bg-emerald-500/20 text-emerald-400"
                            : "bg-rose-500/20 text-rose-400"
                        }`}
                      >
                        {res.alive ? "ALIVE" : res.error || "DEAD"}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
