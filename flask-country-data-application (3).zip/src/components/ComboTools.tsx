"use client";

import React, { useState } from "react";
import {
  Wrench,
  CheckCircle2,
  Shuffle,
  Filter,
  Copy,
  Check,
  ArrowRight,
  Trash2,
  FileSpreadsheet,
} from "lucide-react";
import { soundEngine } from "@/lib/audio";

interface ComboToolsProps {
  onApplyCombos: (combosText: string) => void;
}

export function ComboTools({ onApplyCombos }: ComboToolsProps) {
  const [inputText, setInputText] = useState("");
  const [outputText, setOutputText] = useState("");
  const [copied, setCopied] = useState(false);
  const [stats, setStats] = useState<{
    originalLines: number;
    cleanedLines: number;
    removedDupes: number;
  } | null>(null);

  const cleanAndDedupe = () => {
    soundEngine.playClick();
    const lines = inputText.split("\n");
    const originalLines = lines.length;
    const seen = new Set<string>();
    const cleaned: string[] = [];

    for (const raw of lines) {
      const line = raw.trim();
      if (!line) continue;

      // Check if line contains a colon
      if (line.includes(":")) {
        // Handle lines formatted like "user:pass | other | details"
        const parts = line.split("|")[0].trim();
        const colonIdx = parts.indexOf(":");
        if (colonIdx > 0) {
          const u = parts.slice(0, colonIdx).trim();
          const p = parts.slice(colonIdx + 1).trim();
          if (u && p) {
            const pair = `${u}:${p}`;
            if (!seen.has(pair.toLowerCase())) {
              seen.add(pair.toLowerCase());
              cleaned.push(pair);
            }
          }
        }
      }
    }

    setOutputText(cleaned.join("\n"));
    setStats({
      originalLines,
      cleanedLines: cleaned.length,
      removedDupes: originalLines - cleaned.length,
    });
  };

  const shuffleCombos = () => {
    soundEngine.playClick();
    const target = outputText || inputText;
    const lines = target.split("\n").filter((x) => x.trim());
    for (let i = lines.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [lines[i], lines[j]] = [lines[j], lines[i]];
    }
    setOutputText(lines.join("\n"));
  };

  const copyResult = () => {
    soundEngine.playClick();
    navigator.clipboard.writeText(outputText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const applyToChecker = () => {
    soundEngine.playClick();
    if (outputText.trim()) {
      onApplyCombos(outputText);
    } else if (inputText.trim()) {
      onApplyCombos(inputText);
    }
  };

  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-slate-800/80 bg-slate-900/60 p-5 backdrop-blur-md">
        <div className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-sky-500/10 text-sky-400">
            <Wrench className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white">Combo Suite & Sanitizer</h2>
            <p className="text-xs text-slate-400">
              Clean messy dumps, deduplicate identical pairs, remove syntax noise, and shuffle
            </p>
          </div>
        </div>

        <div className="mt-5 grid grid-cols-1 gap-4 lg:grid-cols-2">
          {/* Input Box */}
          <div className="flex flex-col">
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-slate-300">
                Input Raw Text / Dirty Dump
              </label>
              <button
                onClick={() => setInputText("")}
                className="text-[11px] text-slate-400 hover:text-rose-400 transition"
              >
                Clear
              </button>
            </div>
            <textarea
              rows={12}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={`dirty_user:pass123 | US | 2024\nduplicate:pass\n  messy_user : pass456  \nduplicate:pass\nrandom log line without colon`}
              className="w-full rounded-xl border border-slate-800 bg-slate-950 p-3 font-mono text-xs text-slate-200 placeholder-slate-600 focus:border-sky-500 focus:outline-none"
            />
            <span className="mt-1.5 text-[11px] text-slate-500">
              {inputText.split("\n").filter((x) => x.trim()).length} lines loaded
            </span>
          </div>

          {/* Output Box */}
          <div className="flex flex-col">
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-slate-300">
                Sanitized & Cleaned Combos
              </label>
              <div className="flex items-center gap-2">
                {outputText && (
                  <button
                    onClick={copyResult}
                    className="flex items-center gap-1 text-[11px] text-sky-400 hover:text-sky-300 transition"
                  >
                    {copied ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                    <span>{copied ? "Copied!" : "Copy"}</span>
                  </button>
                )}
                <button
                  onClick={() => setOutputText("")}
                  className="text-[11px] text-slate-400 hover:text-rose-400 transition"
                >
                  Clear
                </button>
              </div>
            </div>
            <textarea
              rows={12}
              readOnly
              value={outputText}
              placeholder="Sanitized combos will appear here after clicking Clean & Dedupe..."
              className="w-full rounded-xl border border-slate-800 bg-slate-950/80 p-3 font-mono text-xs text-slate-200 placeholder-slate-600 focus:outline-none"
            />
            <span className="mt-1.5 text-[11px] text-emerald-400 font-mono">
              {outputText.split("\n").filter((x) => x.trim()).length} clean valid combos
            </span>
          </div>
        </div>

        {/* Action Controls */}
        <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-slate-800/80 pt-4">
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={cleanAndDedupe}
              className="flex items-center gap-1.5 rounded-xl bg-sky-500 px-4 py-2 text-xs font-bold text-white shadow-md shadow-sky-500/20 transition hover:bg-sky-400"
            >
              <Filter className="h-3.5 w-3.5" />
              <span>Clean & Dedupe</span>
            </button>

            <button
              onClick={shuffleCombos}
              className="flex items-center gap-1.5 rounded-xl border border-slate-700 bg-slate-800 px-3.5 py-2 text-xs font-semibold text-slate-200 transition hover:bg-slate-700"
            >
              <Shuffle className="h-3.5 w-3.5 text-indigo-400" />
              <span>Shuffle Order</span>
            </button>
          </div>

          <button
            onClick={applyToChecker}
            disabled={!outputText && !inputText}
            className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 px-4 py-2 text-xs font-bold text-white shadow-md shadow-emerald-500/20 transition hover:from-emerald-400 hover:to-teal-400 disabled:opacity-40"
          >
            <span>Load into Live Checker</span>
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>

        {/* Stats banner */}
        {stats && (
          <div className="mt-4 flex flex-wrap items-center gap-4 rounded-xl border border-slate-800 bg-slate-950/70 p-3 text-xs">
            <div className="flex items-center gap-1.5 text-slate-400">
              <span>Original Lines:</span>
              <strong className="text-white font-mono">{stats.originalLines}</strong>
            </div>
            <div className="flex items-center gap-1.5 text-emerald-400">
              <CheckCircle2 className="h-3.5 w-3.5" />
              <span>Valid Extracted:</span>
              <strong className="font-mono">{stats.cleanedLines}</strong>
            </div>
            <div className="flex items-center gap-1.5 text-amber-400">
              <span>Duplicates / Noise Removed:</span>
              <strong className="font-mono">{stats.removedDupes}</strong>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
