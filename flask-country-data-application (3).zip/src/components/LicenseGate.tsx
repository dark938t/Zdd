"use client";

import React, { FormEvent, ReactNode, useEffect, useState } from "react";
import {
  KeyRound,
  LockKeyhole,
  LoaderCircle,
  ShieldCheck,
  Sparkles,
  ArrowRight,
  AlertCircle,
} from "lucide-react";
import { soundEngine } from "@/lib/audio";

interface LicenseGateProps {
  children: ReactNode;
}

export function LicenseGate({ children }: LicenseGateProps) {
  const [loading, setLoading] = useState(true);
  const [active, setActive] = useState(false);
  const [configured, setConfigured] = useState(true);
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    let mounted = true;
    fetch("/api/license", { credentials: "same-origin" })
      .then(async (response) => {
        const data = await response.json();
        if (!mounted) return;
        setConfigured(Boolean(data.configured));
        setActive(Boolean(data.active));
      })
      .catch(() => {
        if (mounted) setError("License service is temporarily unavailable.");
      })
      .finally(() => {
        if (mounted) setLoading(false);
      });

    return () => {
      mounted = false;
    };
  }, []);

  const submitCode = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError("");
    setSubmitting(true);
    soundEngine.playClick();

    try {
      const response = await fetch("/api/license", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        body: JSON.stringify({ code }),
      });
      const data = await response.json();

      if (!response.ok || !data.valid) {
        setError(data.error || "That license key is invalid or expired.");
        return;
      }

      soundEngine.playComplete();
      setActive(true);
    } catch {
      setError("Could not contact the license service. Try again.");
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#080c14] text-slate-200">
        <div className="flex flex-col items-center gap-3">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl border border-sky-500/30 bg-sky-500/10">
            <LoaderCircle className="h-7 w-7 animate-spin text-sky-400" />
          </div>
          <span className="font-mono text-xs tracking-widest text-slate-500 uppercase">Initializing secure access</span>
        </div>
      </div>
    );
  }

  if (active || !configured) {
    return <>{children}</>;
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[#080c14] px-4 py-8 text-slate-100 scanline-bg">
      <div className="pointer-events-none absolute -top-48 left-1/2 h-[520px] w-[900px] -translate-x-1/2 rounded-full bg-sky-500/10 blur-3xl" />
      <div className="pointer-events-none absolute bottom-0 left-0 h-80 w-80 rounded-full bg-indigo-500/10 blur-3xl" />
      <div className="pointer-events-none absolute right-0 bottom-0 h-80 w-80 rounded-full bg-emerald-500/5 blur-3xl" />

      <div className="relative w-full max-w-md overflow-hidden rounded-3xl border border-slate-700/80 bg-slate-900/90 shadow-2xl shadow-sky-950/40 backdrop-blur-xl">
        <div className="h-1 bg-gradient-to-r from-sky-500 via-indigo-500 to-emerald-400" />

        <div className="p-7 sm:p-9">
          <div className="flex items-center justify-between">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-sky-400/30 bg-gradient-to-br from-sky-500/20 to-indigo-500/20 text-sky-400">
              <LockKeyhole className="h-6 w-6" />
            </div>
            <span className="flex items-center gap-1.5 rounded-full border border-emerald-500/20 bg-emerald-500/10 px-2.5 py-1 text-[10px] font-bold tracking-wider text-emerald-400 uppercase">
              <ShieldCheck className="h-3 w-3" />
              Secure Access
            </span>
          </div>

          <div className="mt-7">
            <p className="text-xs font-bold tracking-[0.22em] text-sky-400 uppercase">STEAMENGINE // LICENSED</p>
            <h1 className="mt-2 text-3xl font-bold tracking-tight text-white">Enter weekly key</h1>
            <p className="mt-3 text-sm leading-6 text-slate-400">
              This workspace uses one rotating license per UTC week. Enter the key provided by your administrator to unlock the checker and vault.
            </p>
          </div>

          <form onSubmit={submitCode} className="mt-7">
            <label className="mb-2 block text-xs font-semibold text-slate-300">Weekly license key</label>
            <div className="relative">
              <KeyRound className="pointer-events-none absolute left-3 top-3.5 h-4 w-4 text-slate-500" />
              <input
                autoFocus
                autoComplete="off"
                spellCheck={false}
                value={code}
                onChange={(event) => setCode(event.target.value.toUpperCase())}
                placeholder="STEAM-XXXXXXXXXXXX-XXXXXXXXXXXX"
                className="w-full rounded-xl border border-slate-700 bg-slate-950 py-3 pl-10 pr-3 font-mono text-sm tracking-wider text-white outline-none transition placeholder:text-slate-700 focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20"
              />
            </div>

            {error && (
              <div className="mt-3 flex items-start gap-2 rounded-xl border border-rose-500/25 bg-rose-950/30 px-3 py-2.5 text-xs leading-5 text-rose-300">
                <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={submitting || !code.trim()}
              className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-500 px-4 py-3 text-sm font-bold text-white shadow-lg shadow-sky-500/20 transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-40"
            >
              {submitting ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <ArrowRight className="h-4 w-4" />}
              <span>{submitting ? "Verifying access..." : "Unlock SteamEngine"}</span>
            </button>
          </form>

          <div className="mt-6 flex items-start gap-2.5 border-t border-slate-800 pt-5 text-[11px] leading-5 text-slate-500">
            <Sparkles className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-400" />
            <span>A new key is generated and delivered to the private Discord license channel once per week. Keys expire at the next Monday 00:00 UTC.</span>
          </div>
        </div>
      </div>
    </div>
  );
}
