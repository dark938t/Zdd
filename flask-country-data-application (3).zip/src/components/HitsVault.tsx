"use client";

import React, { useState, useEffect } from "react";
import {
  Database,
  Trash2,
  Download,
  Search,
  Eye,
  Copy,
  Check,
  RotateCcw,
  Gamepad2,
  Wallet,
  Globe,
  Clock,
  ExternalLink,
  Users,
} from "lucide-react";
import { ComboResultItem } from "@/lib/steam/constants";
import { soundEngine } from "@/lib/audio";

interface HitsVaultProps {
  onInspect: (item: ComboResultItem) => void;
}

export function HitsVault({ onInspect }: HitsVaultProps) {
  const [runs, setRuns] = useState<any[]>([]);
  const [recentHits, setRecentHits] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [copiedId, setCopiedId] = useState<number | null>(null);

  const fetchHistory = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/history");
      const data = await res.json();
      if (data.runs) setRuns(data.runs);
      if (data.recentHits) setRecentHits(data.recentHits);
    } catch (err) {
      console.error("Failed to load history:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHistory();
  }, []);

  const deleteRun = async (runId: number) => {
    soundEngine.playClick();
    if (!confirm("Are you sure you want to delete this scan run?")) return;
    try {
      await fetch(`/api/history?runId=${runId}`, { method: "DELETE" });
      setRuns(runs.filter((r) => r.id !== runId));
      setRecentHits(recentHits.filter((h) => h.runId !== runId));
    } catch (err) {
      console.error("Delete failed:", err);
    }
  };

  const clearAllHistory = async () => {
    soundEngine.playClick();
    if (!confirm("Are you sure you want to wipe all past runs and saved hits from the database?")) return;
    try {
      await fetch("/api/history", { method: "DELETE" });
      setRuns([]);
      setRecentHits([]);
    } catch (err) {
      console.error("Clear all failed:", err);
    }
  };

  const copyCombo = (combo: string, id: number) => {
    soundEngine.playClick();
    navigator.clipboard.writeText(combo);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  const exportVaultTxt = () => {
    soundEngine.playClick();
    let text = "";
    recentHits.forEach((h) => {
      const faTag = h.fa ? " | FA" : "";
      const sessions = h.activeSessions !== undefined && h.activeSessions !== null ? ` | Sessions:${h.activeSessions}` : "";
      text += `[${h.status.toUpperCase()}] ${h.combo} | SteamID:${h.steamId || "N/A"} | Level:${h.level || "0"} | Games:${h.gamesCount || 0} | Wallet:${h.walletBalance || "N/A"} | Country:${h.country || h.countryCode || "N/A"}${sessions}${faTag}\n`;
      const games: string[] = h.gameList || [];
      if (games.length > 0) {
        text += `  Games: ${games.join(", ")}\n`;
      }
    });
    const blob = new Blob([text], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `steam_vault_hits_${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportVaultJson = () => {
    soundEngine.playClick();
    const blob = new Blob([JSON.stringify(recentHits, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `steam_vault_hits_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const filteredHits = recentHits.filter((h) => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (
      (h.username && h.username.toLowerCase().includes(q)) ||
      (h.combo && h.combo.toLowerCase().includes(q)) ||
      (h.steamId && h.steamId.toLowerCase().includes(q)) ||
      (h.country && h.country.toLowerCase().includes(q))
    );
  });

  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-slate-800/80 bg-slate-900/60 p-5 backdrop-blur-md">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-sky-500/10 text-sky-400">
              <Database className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">PostgreSQL Hits Vault</h2>
              <p className="text-xs text-slate-400">
                Persistent database records of previous scan sessions and valuable hits
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={fetchHistory}
              title="Refresh vault"
              className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-800 bg-slate-950 text-slate-400 hover:text-slate-200"
            >
              <RotateCcw className={`h-3.5 w-3.5 ${loading ? "animate-spin" : ""}`} />
            </button>

            {recentHits.length > 0 && (
              <>
                <button
                  onClick={exportVaultTxt}
                  className="flex items-center gap-1 rounded-lg border border-slate-800 bg-slate-950 px-2.5 py-1.5 text-xs font-semibold text-slate-300 hover:bg-slate-800"
                >
                  <Download className="h-3.5 w-3.5 text-sky-400" />
                  <span>Export TXT</span>
                </button>

                <button
                  onClick={exportVaultJson}
                  className="flex items-center gap-1 rounded-lg border border-slate-800 bg-slate-950 px-2.5 py-1.5 text-xs font-semibold text-slate-300 hover:bg-slate-800"
                >
                  <Download className="h-3.5 w-3.5 text-indigo-400" />
                  <span>Export JSON</span>
                </button>

                <button
                  onClick={clearAllHistory}
                  className="flex items-center gap-1 rounded-lg border border-rose-900/40 bg-rose-950/30 px-2.5 py-1.5 text-xs font-semibold text-rose-400 hover:bg-rose-900/50"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  <span>Wipe Vault</span>
                </button>
              </>
            )}
          </div>
        </div>

        {/* Scan Sessions Overview */}
        {runs.length > 0 && (
          <div className="mt-4">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
              Recent Scan Sessions ({runs.length})
            </h3>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3">
              {runs.slice(0, 6).map((run) => (
                <div
                  key={run.id}
                  className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-950/70 p-3 text-xs"
                >
                  <div>
                    <span className="font-bold text-slate-200">{run.title}</span>
                    <div className="mt-1 flex items-center gap-2 text-[11px] text-slate-400">
                      <span className="text-emerald-400 font-semibold">{run.hitCount} hits</span>
                      <span>•</span>
                      <span className="text-amber-400">{run.faCount} 2fa</span>
                      <span>•</span>
                      <span className="text-slate-400">{run.totalCombos} total</span>
                    </div>
                  </div>

                  <button
                    onClick={() => deleteRun(run.id)}
                    className="p-1 text-slate-500 hover:text-rose-400 transition"
                    title="Delete session"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Saved Hits Database List */}
        <div className="mt-6">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Saved Hits ({recentHits.length})
            </h3>

            <div className="relative w-48">
              <Search className="absolute left-2.5 top-2 h-3.5 w-3.5 text-slate-500" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search hits..."
                className="w-full rounded-lg border border-slate-800 bg-slate-950 py-1 pl-8 pr-2.5 text-xs text-slate-200 placeholder-slate-500 focus:border-sky-500 focus:outline-none"
              />
            </div>
          </div>

          {filteredHits.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 rounded-xl border border-dashed border-slate-800 text-slate-500 text-xs">
              <Database className="h-8 w-8 text-slate-700 mb-2" />
              <span>No hits stored in database yet. Run a check to capture and persist hits!</span>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
              {filteredHits.map((hit) => {
                const itemForInspect: ComboResultItem = {
                  id: String(hit.id),
                  combo: hit.combo,
                  username: hit.username,
                  result: {
                    st: hit.status as any,
                    sid: hit.steamId,
                    level: hit.level,
                    games: hit.gamesCount,
                    balance: hit.walletBalance,
                    country: hit.country,
                    cc: hit.countryCode,
                    game_list: hit.gameList || [],
                    types: hit.twoFactorTypes,
                    info: hit.info,
                    fa: hit.fa ?? undefined,
                    activeSessions: hit.activeSessions ?? undefined,
                  },
                  timestamp: hit.createdAt ? new Date(hit.createdAt).getTime() : Date.now(),
                };

                return (
                  <div
                    key={hit.id}
                    className="flex flex-col justify-between rounded-xl border border-emerald-500/25 bg-slate-950/80 p-3.5 hover:border-emerald-500/50 transition"
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          <span className="rounded bg-emerald-500/20 px-1.5 py-0.5 text-[10px] font-bold text-emerald-400 uppercase">
                            [{hit.status.toUpperCase()}]
                          </span>
                          {hit.fa && (
                            <span className="rounded bg-violet-500/20 px-1.5 py-0.5 text-[10px] font-bold text-violet-300 uppercase" title="First Access — nobody else is using this account">
                              FA
                            </span>
                          )}
                        </div>
                        {hit.level && (
                          <span className="font-mono text-[10px] text-amber-400 font-bold">
                            Lv.{hit.level}
                          </span>
                        )}
                      </div>

                      <div className="mt-2">
                        <h4 className="font-mono text-xs font-bold text-white truncate">
                          {hit.username}
                        </h4>
                        <p className="font-mono text-[11px] text-slate-400 truncate">
                          {hit.combo}
                        </p>
                      </div>

                      <div className="mt-2 flex flex-wrap gap-1.5 text-[11px]">
                        {hit.walletBalance && (
                          <span className="flex items-center gap-1 rounded bg-slate-900 px-1.5 py-0.5 text-emerald-400 font-mono">
                            <Wallet className="h-3 w-3" />
                            {hit.walletBalance}
                          </span>
                        )}
                        {hit.country && (
                          <span className="flex items-center gap-1 rounded bg-slate-900 px-1.5 py-0.5 text-sky-400">
                            <Globe className="h-3 w-3" />
                            {hit.country}
                          </span>
                        )}
                        {hit.gamesCount !== undefined && hit.gamesCount > 0 && (
                          <span className="flex items-center gap-1 rounded bg-slate-900 px-1.5 py-0.5 text-indigo-400">
                            <Gamepad2 className="h-3 w-3" />
                            {hit.gamesCount} games
                          </span>
                        )}
                        {hit.activeSessions !== undefined && hit.activeSessions !== null && (
                          <span className="flex items-center gap-1 rounded bg-slate-900 px-1.5 py-0.5 text-slate-300" title="Active sessions currently using the account">
                            <Users className="h-3 w-3 text-sky-400" />
                            {hit.activeSessions} online
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="mt-3 flex items-center justify-between border-t border-slate-800/80 pt-2 text-[11px]">
                      <button
                        onClick={() => copyCombo(hit.combo, hit.id)}
                        className="flex items-center gap-1 text-slate-400 hover:text-slate-200"
                      >
                        {copiedId === hit.id ? (
                          <Check className="h-3.5 w-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="h-3.5 w-3.5" />
                        )}
                        <span>{copiedId === hit.id ? "Copied" : "Copy"}</span>
                      </button>

                      <button
                        onClick={() => onInspect(itemForInspect)}
                        className="flex items-center gap-1 font-semibold text-sky-400 hover:underline"
                      >
                        <Eye className="h-3.5 w-3.5" />
                        <span>Inspect</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
