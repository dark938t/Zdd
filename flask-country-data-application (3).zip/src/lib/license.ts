import crypto from "crypto";
import { and, eq, isNull, lt, or } from "drizzle-orm";
import { db } from "@/db";
import { weeklyLicenses, WeeklyLicense } from "@/db/schema";

const LICENSE_COOKIE = "steamengine_license";
const CLAIM_TIMEOUT_MS = 5 * 60 * 1000;

export function licenseCookieName() {
  return LICENSE_COOKIE;
}

export function currentWeekKey(date = new Date()) {
  // Monday-based UTC week key. This keeps generation consistent across servers.
  const utc = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));
  const day = utc.getUTCDay() || 7;
  utc.setUTCDate(utc.getUTCDate() - day + 1);
  return utc.toISOString().slice(0, 10);
}

function hashLicense(code: string) {
  return crypto.createHash("sha256").update(code, "utf8").digest("hex");
}

function makeLicenseCode() {
  const first = crypto.randomBytes(6).toString("hex").toUpperCase();
  const second = crypto.randomBytes(6).toString("hex").toUpperCase();
  return `STEAM-${first}-${second}`;
}

function safeEqualHex(left: string, right: string) {
  const a = Buffer.from(left, "hex");
  const b = Buffer.from(right, "hex");
  return a.length === b.length && a.length > 0 && crypto.timingSafeEqual(a, b);
}

async function sendWeeklyCodeToDiscord(license: WeeklyLicense) {
  const webhookUrl = process.env.DISCORD_LICENSE_WEBHOOK;
  if (!webhookUrl) {
    console.warn("DISCORD_LICENSE_WEBHOOK is not configured; weekly code was stored but not delivered.");
    return false;
  }

  const claimCutoff = new Date(Date.now() - CLAIM_TIMEOUT_MS);
  const [claimed] = await db
    .update(weeklyLicenses)
    .set({ webhookClaimedAt: new Date() })
    .where(
      and(
        eq(weeklyLicenses.id, license.id),
        isNull(weeklyLicenses.webhookSentAt),
        or(isNull(weeklyLicenses.webhookClaimedAt), lt(weeklyLicenses.webhookClaimedAt, claimCutoff))
      )
    )
    .returning();

  if (!claimed) {
    return false;
  }

  try {
    const response = await fetch(webhookUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        username: "SteamEngine License Bot",
        embeds: [
          {
            title: "Weekly SteamEngine License",
            description: "A new license key was generated for the current UTC week.",
            color: 1712128,
            fields: [
              { name: "License key", value: `\`${license.licenseCode}\``, inline: false },
              { name: "Valid week starts", value: license.weekKey, inline: true },
              { name: "Valid until", value: "Next Monday 00:00 UTC", inline: true },
            ],
            footer: { text: "Keep this key private." },
            timestamp: new Date().toISOString(),
          },
        ],
      }),
    });

    if (!response.ok) {
      throw new Error(`Discord webhook returned ${response.status}`);
    }

    await db
      .update(weeklyLicenses)
      .set({ webhookSentAt: new Date(), webhookClaimedAt: null })
      .where(eq(weeklyLicenses.id, license.id));

    return true;
  } catch (error) {
    await db
      .update(weeklyLicenses)
      .set({ webhookClaimedAt: null })
      .where(eq(weeklyLicenses.id, license.id));
    console.error("Weekly license Discord delivery failed:", error);
    return false;
  }
}

export async function getOrCreateWeeklyLicense() {
  const weekKey = currentWeekKey();
  const [existing] = await db
    .select()
    .from(weeklyLicenses)
    .where(eq(weeklyLicenses.weekKey, weekKey))
    .limit(1);

  if (existing) {
    if (!existing.webhookSentAt) {
      await sendWeeklyCodeToDiscord(existing);
    }
    return existing;
  }

  const licenseCode = makeLicenseCode();
  const [created] = await db
    .insert(weeklyLicenses)
    .values({
      weekKey,
      licenseCode,
      licenseHash: hashLicense(licenseCode),
    })
    .onConflictDoNothing({ target: weeklyLicenses.weekKey })
    .returning();

  if (created) {
    await sendWeeklyCodeToDiscord(created);
    return created;
  }

  // Another request won the unique weekly insert race.
  const [winner] = await db
    .select()
    .from(weeklyLicenses)
    .where(eq(weeklyLicenses.weekKey, weekKey))
    .limit(1);

  if (!winner) {
    throw new Error("Unable to initialize weekly license");
  }

  if (!winner.webhookSentAt) {
    await sendWeeklyCodeToDiscord(winner);
  }
  return winner;
}

export async function validateWeeklyLicense(code: string) {
  const license = await getOrCreateWeeklyLicense();
  const normalized = String(code || "").trim().toUpperCase();
  if (!normalized) return false;
  return safeEqualHex(license.licenseHash, hashLicense(normalized));
}

export async function requestHasValidLicense(request: Request) {
  // If the deployment has not been configured yet, keep the polished UI
  // previewable. Once DISCORD_LICENSE_WEBHOOK is set, the gate is enforced.
  if (!process.env.DISCORD_LICENSE_WEBHOOK) {
    return true;
  }

  const cookieHeader = request.headers.get("cookie") || "";
  const match = cookieHeader.match(new RegExp(`${LICENSE_COOKIE}=([^;]+)`));
  const cookieHash = match?.[1] || "";
  if (!cookieHash) return false;

  const license = await getOrCreateWeeklyLicense();
  return safeEqualHex(license.licenseHash, decodeURIComponent(cookieHash));
}

export function licenseHashForCookie(code: string) {
  return hashLicense(code);
}
