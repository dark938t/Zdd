import { AccountCheckResult } from "./constants";

export interface DemoAccount {
  combo: string;
  username: string;
  password?: string;
  result: AccountCheckResult;
}

export const SAMPLE_COMBOS_TEXT = `cyber_phantom:Valkyrie992#
nova_tactics:ShadowStrike2024
gaben_disciple:HalfLifeForever!
phoenix_rising:FireBird77
arctic_wolf:FrostBite44
steampunk_pilot:AeroGear99
reaper_main:DeathBlossom#1
rusty_survivor:NakedRock2023
casual_gamer:password12345
banned_hacker:AimBotV2.0
bad_login_user:wrongPassword!
proxy_fail_test:networkError123`;

export const DEMO_PRESET_ACCOUNTS: DemoAccount[] = [
  {
    combo: "cyber_phantom:Valkyrie992#",
    username: "cyber_phantom",
    password: "••••••••••••",
    result: {
      st: "hit",
      sid: "76561198034567891",
      country: "United States",
      cc: "US",
      level: "74",
      games: 48,
      balance: "$64.50 USD",
      activeSessions: 3,
      fa: false,
      sessionDetails: ["Windows PC / Steam Client", "Android / Steam Mobile", "Web Browser / Chrome"],
      game_list: [
        "Counter-Strike 2",
        "Cyberpunk 2077",
        "Elden Ring",
        "Baldur's Gate 3",
        "Grand Theft Auto V",
        "Rust",
        "Apex Legends",
        "Dota 2",
        "Tom Clancy's Rainbow Six Siege",
        "Black Myth: Wukong",
        "Helldivers 2",
        "Palworld",
        "The Witcher 3: Wild Hunt",
        "Team Fortress 2",
        "Red Dead Redemption 2",
      ],
    },
  },
  {
    combo: "nova_tactics:ShadowStrike2024",
    username: "nova_tactics",
    password: "••••••••••••",
    result: {
      st: "hit",
      sid: "76561198123456780",
      country: "Germany",
      cc: "DE",
      level: "42",
      games: 21,
      balance: "€28.75 EUR",
      activeSessions: 1,
      fa: true,
      sessionDetails: ["Windows PC / Steam Client"],
      game_list: [
        "Counter-Strike 2",
        "Euro Truck Simulator 2",
        "Rust",
        "Garry's Mod",
        "Terraria",
        "Stardew Valley",
        "Left 4 Dead 2",
        "Phasmophobia",
      ],
    },
  },
  {
    combo: "gaben_disciple:HalfLifeForever!",
    username: "gaben_disciple",
    password: "••••••••••••",
    result: {
      st: "2fa",
      sid: "76561197998877665",
      types: "2 (Steam Mobile Authenticator)",
      info: "Steam Guard Mobile Auth required",
    },
  },
  {
    combo: "phoenix_rising:FireBird77",
    username: "phoenix_rising",
    password: "••••••••••••",
    result: {
      st: "hit",
      sid: "76561198889900112",
      country: "United Kingdom",
      cc: "GB",
      level: "35",
      games: 16,
      balance: "£14.20 GBP",
      activeSessions: 2,
      fa: false,
      sessionDetails: ["Windows PC / Steam Client", "Steam Deck"],
      game_list: [
        "EA SPORTS FC 24",
        "Rocket League",
        "Football Manager 2024",
        "Counter-Strike 2",
        "Fall Guys",
      ],
    },
  },
  {
    combo: "arctic_wolf:FrostBite44",
    username: "arctic_wolf",
    password: "••••••••••••",
    result: {
      st: "free",
      sid: "76561198334455667",
      country: "Canada",
      cc: "CA",
      level: "4",
      games: 3,
      balance: "$0.00 CAD",
      activeSessions: 1,
      fa: true,
      sessionDetails: ["Linux / Steam Client"],
      game_list: ["Counter-Strike 2", "Dota 2", "Team Fortress 2"],
    },
  },
  {
    combo: "steampunk_pilot:AeroGear99",
    username: "steampunk_pilot",
    password: "••••••••••••",
    result: {
      st: "2fa",
      sid: "76561198223344556",
      types: "3 (Email Code)",
      info: "Steam Guard Email confirmation required",
    },
  },
  {
    combo: "reaper_main:DeathBlossom#1",
    username: "reaper_main",
    password: "••••••••••••",
    result: {
      st: "bad",
      info: "Invalid password / username",
    },
  },
  {
    combo: "rusty_survivor:NakedRock2023",
    username: "rusty_survivor",
    password: "••••••••••••",
    result: {
      st: "hit",
      sid: "76561198556677889",
      country: "Australia",
      cc: "AU",
      level: "26",
      games: 9,
      balance: "A$5.10 AUD",
      activeSessions: 1,
      fa: true,
      sessionDetails: ["macOS / Steam Client"],
      game_list: ["Rust", "ARK: Survival Evolved", "DayZ", "Sons of the Forest"],
    },
  },
  {
    combo: "casual_gamer:password12345",
    username: "casual_gamer",
    password: "••••••••••••",
    result: {
      st: "bad",
      info: "Invalid login credentials",
    },
  },
  {
    combo: "banned_hacker:AimBotV2.0",
    username: "banned_hacker",
    password: "••••••••••••",
    result: {
      st: "ban",
      info: "Account suspended or community banned (eresult=63)",
    },
  },
  {
    combo: "bad_login_user:wrongPassword!",
    username: "bad_login_user",
    password: "••••••••••••",
    result: {
      st: "bad",
      info: "Password incorrect (eresult=5)",
    },
  },
  {
    combo: "proxy_fail_test:networkError123",
    username: "proxy_fail_test",
    password: "••••••••••••",
    result: {
      st: "err",
      info: "timeout (15s)",
    },
  },
];
