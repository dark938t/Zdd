export const COUNTRIES: Record<string, string> = {
  AF: "Afghanistan", AX: "Aland Islands", AL: "Albania", DZ: "Algeria",
  AS: "American Samoa", AD: "Andorra", AO: "Angola", AI: "Anguilla",
  AG: "Antigua and Barbuda", AR: "Argentina", AM: "Armenia", AW: "Aruba",
  AU: "Australia", AT: "Austria", AZ: "Azerbaijan", BS: "Bahamas",
  BH: "Bahrain", BD: "Bangladesh", BB: "Barbados", BY: "Belarus",
  BE: "Belgium", BZ: "Belize", BJ: "Benin", BM: "Bermuda",
  BT: "Bhutan", BO: "Bolivia", BA: "Bosnia and Herzegovina", BW: "Botswana",
  BR: "Brazil", BN: "Brunei", BG: "Bulgaria", BF: "Burkina Faso",
  BI: "Burundi", KH: "Cambodia", CM: "Cameroon", CA: "Canada",
  CV: "Cape Verde", KY: "Cayman Islands", CF: "Central African Republic",
  TD: "Chad", CL: "Chile", CN: "China", CO: "Colombia",
  KM: "Comoros", CG: "Congo", CD: "DR Congo", CK: "Cook Islands",
  CR: "Costa Rica", CI: "Cote d'Ivoire", HR: "Croatia", CU: "Cuba",
  CW: "Curacao", CY: "Cyprus", CZ: "Czech Republic", DK: "Denmark",
  DJ: "Djibouti", DM: "Dominica", DO: "Dominican Republic", EC: "Ecuador",
  EG: "Egypt", SV: "El Salvador", GQ: "Equatorial Guinea", ER: "Eritrea",
  EE: "Estonia", ET: "Ethiopia", FK: "Falkland Islands", FO: "Faroe Islands",
  FJ: "Fiji", FI: "Finland", FR: "France", GF: "French Guiana",
  PF: "French Polynesia", GA: "Gabon", GM: "Gambia", GE: "Georgia",
  DE: "Germany", GH: "Ghana", GI: "Gibraltar", GR: "Greece",
  GL: "Greenland", GD: "Grenada", GP: "Guadeloupe", GU: "Guam",
  GT: "Guatemala", GG: "Guernsey", GN: "Guinea", GW: "Guinea-Bissau",
  GY: "Guyana", HT: "Haiti", VA: "Vatican", HN: "Honduras",
  HK: "Hong Kong", HU: "Hungary", IS: "Iceland", IN: "India",
  ID: "Indonesia", IR: "Iran", IQ: "Iraq", IE: "Ireland",
  IM: "Isle of Man", IL: "Israel", IT: "Italy", JM: "Jamaica",
  JP: "Japan", JE: "Jersey", JO: "Jordan", KZ: "Kazakhstan",
  KE: "Kenya", KI: "Kiribati", KP: "North Korea", KR: "South Korea",
  KW: "Kuwait", KG: "Kyrgyzstan", LA: "Laos", LV: "Latvia",
  LB: "Lebanon", LS: "Lesotho", LR: "Liberia", LY: "Libya",
  LI: "Liechtenstein", LT: "Lithuania", LU: "Luxembourg", MO: "Macao",
  MK: "North Macedonia", MG: "Madagascar", MW: "Malawi", MY: "Malaysia",
  MV: "Maldives", ML: "Mali", MT: "Malta", MH: "Marshall Islands",
  MQ: "Martinique", MR: "Mauritania", MU: "Mauritius", YT: "Mayotte",
  MX: "Mexico", FM: "Micronesia", MD: "Moldova", MC: "Monaco",
  MN: "Mongolia", ME: "Montenegro", MS: "Montserrat", MA: "Morocco",
  MZ: "Mozambique", MM: "Myanmar", NA: "Namibia", NR: "Nauru",
  NP: "Nepal", NL: "Netherlands", NC: "New Caledonia", NZ: "New Zealand",
  NI: "Nicaragua", NE: "Niger", NG: "Nigeria", NU: "Niue",
  NF: "Norfolk Island", MP: "N. Mariana Islands", NO: "Norway", OM: "Oman",
  PK: "Pakistan", PW: "Palau", PS: "Palestine", PA: "Panama",
  PG: "Papua New Guinea", PY: "Paraguay", PE: "Peru", PH: "Philippines",
  PL: "Poland", PT: "Portugal", PR: "Puerto Rico", QA: "Qatar",
  RE: "Reunion", RO: "Romania", RU: "Russia", RW: "Rwanda",
  SA: "Saudi Arabia", SN: "Senegal", RS: "Serbia", SC: "Seychelles",
  SL: "Sierra Leone", SG: "Singapore", SX: "Sint Maarten", SK: "Slovakia",
  SI: "Slovenia", SB: "Solomon Islands", SO: "Somalia", ZA: "South Africa",
  SS: "South Sudan", ES: "Spain", LK: "Sri Lanka", SD: "Sudan",
  SR: "Suriname", SZ: "Eswatini", SE: "Sweden", CH: "Switzerland",
  SY: "Syria", TW: "Taiwan", TJ: "Tajikistan", TZ: "Tanzania",
  TH: "Thailand", TL: "Timor-Leste", TG: "Togo", TO: "Tonga",
  TT: "Trinidad and Tobago", TN: "Tunisia", TR: "Turkey", TM: "Turkmenistan",
  TC: "Turks and Caicos", TV: "Tuvalu", UG: "Uganda", UA: "Ukraine",
  AE: "UAE", GB: "United Kingdom", US: "United States", UY: "Uruguay",
  UZ: "Uzbekistan", VU: "Vanuatu", VE: "Venezuela", VN: "Vietnam",
  VG: "British Virgin Islands", VI: "US Virgin Islands", WF: "Wallis and Futuna",
  EH: "Western Sahara", YE: "Yemen", ZM: "Zambia", ZW: "Zimbabwe",
};

export interface CheckStats {
  done: number;
  hit: number;
  "2fa": number;
  free: number;
  bad: number;
  ban: number;
  err: number;
  fa: number;
}

export type ResultStatus = "hit" | "2fa" | "free" | "bad" | "ban" | "err";

export interface AccountCheckResult {
  st: ResultStatus;
  sid?: string;
  country?: string;
  cc?: string;
  level?: string;
  games?: number;
  balance?: string;
  game_list?: string[];
  types?: string;
  info?: string;
  /** Number of active sessions/devices currently using the account */
  activeSessions?: number;
  /** "First Access" — true when nobody else is using the account */
  fa?: boolean;
  /** Human-readable list of active session descriptions */
  sessionDetails?: string[];
}

export interface ComboResultItem {
  id: string;
  combo: string;
  username: string;
  password?: string;
  result: AccountCheckResult;
  timestamp: number;
}
