/**
 * Minimal Steam Protobuf encoder / decoder in pure TypeScript / Node.js
 */

const ZERO = BigInt(0);
const ONE = BigInt(1);
const TWO = BigInt(2);
const THREE = BigInt(3);
const SEVEN = BigInt(7);
const MASK_7F = BigInt(0x7f);
const BIT_80 = BigInt(0x80);
const MAX_64 = BigInt("0xffffffffffffffff");

export function varint(v: number | bigint): Buffer {
  let val = BigInt(v);
  if (val < ZERO) {
    val = val & MAX_64;
  }
  const buf: number[] = [];
  while (val > MASK_7F) {
    buf.push(Number((val & MASK_7F) | BIT_80));
    val >>= SEVEN;
  }
  buf.push(Number(val & MASK_7F));
  return Buffer.from(buf);
}

export function readVarint(buf: Buffer, pos: number): [bigint, number] {
  let result = ZERO;
  let shift = ZERO;
  while (pos < buf.length) {
    const b = BigInt(buf[pos]);
    pos += 1;
    result |= (b & MASK_7F) << shift;
    if ((b & BIT_80) === ZERO) {
      break;
    }
    shift += SEVEN;
  }
  return [result, pos];
}

export function pbStr(field: number, s: string | Buffer): Buffer {
  const data = typeof s === "string" ? Buffer.from(s, "utf8") : s;
  return Buffer.concat([
    varint((field << 3) | 2),
    varint(data.length),
    data,
  ]);
}

export function pbBytes(field: number, data: Buffer): Buffer {
  return Buffer.concat([
    varint((field << 3) | 2),
    varint(data.length),
    data,
  ]);
}

export function pbInt(field: number, v: number | bigint): Buffer {
  let val = BigInt(v);
  if (val < ZERO) {
    val = val & MAX_64;
  }
  return Buffer.concat([
    varint((field << 3) | 0),
    varint(val),
  ]);
}

export type DecodedProtobuf = Record<number, any>;

export function pbDecode(raw: Buffer): DecodedProtobuf {
  const out: DecodedProtobuf = {};
  let pos = 0;
  while (pos < raw.length) {
    try {
      const [tag, nextPos] = readVarint(raw, pos);
      pos = nextPos;
      const field = Number(tag >> THREE);
      const wire = Number(tag & SEVEN);
      if (field < 1) break;

      if (wire === 0) {
        // Varint
        const [val, npos] = readVarint(raw, pos);
        pos = npos;
        const prev = out[field];
        if (prev !== undefined) {
          out[field] = Array.isArray(prev) ? [...prev, val] : [prev, val];
        } else {
          out[field] = val;
        }
      } else if (wire === 2) {
        // Length-delimited: string, bytes, embedded message
        const [lnBig, npos] = readVarint(raw, pos);
        pos = npos;
        const ln = Number(lnBig);
        if (pos + ln > raw.length) break;
        const chunk = raw.subarray(pos, pos + ln);
        pos += ln;
        const prev = out[field];
        if (prev !== undefined) {
          out[field] = Array.isArray(prev) ? [...prev, chunk] : [prev, chunk];
        } else {
          out[field] = chunk;
        }
      } else if (wire === 5) {
        // 32-bit
        if (pos + 4 > raw.length) break;
        const val = raw.readUInt32LE(pos);
        pos += 4;
        out[field] = val;
      } else if (wire === 1) {
        // 64-bit
        if (pos + 8 > raw.length) break;
        const val = raw.readBigUInt64LE(pos);
        pos += 8;
        out[field] = val;
      } else {
        // Unsupported wire type
        break;
      }
    } catch {
      break;
    }
  }
  return out;
}
