import crypto from "crypto";

/**
 * Standard RSA PKCS#1 v1.5 encryption using BigInt modular exponentiation,
 * perfectly equivalent to Python's pow(int.from_bytes(block, 'big'), e, n).
 */
export function rsaEncrypt(password: string, modHex: string, expHex: string): string {
  const modBytes = Buffer.from(modHex, "hex");
  const n = BigInt("0x" + modHex);
  const e = BigInt("0x" + expHex);
  const pw = Buffer.from(password, "utf8");
  const k = modBytes.length;

  const padLen = k - pw.length - 3;
  if (padLen < 8) {
    throw new Error("Password too long for RSA key size");
  }

  const padding = Buffer.alloc(padLen);
  for (let i = 0; i < padLen; i++) {
    let r = 0;
    while (r === 0) {
      r = crypto.randomInt(1, 256);
    }
    padding[i] = r;
  }

  const block = Buffer.concat([
    Buffer.from([0x00, 0x02]),
    padding,
    Buffer.from([0x00]),
    pw,
  ]);

  const m = BigInt("0x" + block.toString("hex"));

  let res = BigInt(1);
  let base = m % n;
  let exp = e;
  const zero = BigInt(0);
  const one = BigInt(1);
  const two = BigInt(2);

  while (exp > zero) {
    if (exp % two === one) {
      res = (res * base) % n;
    }
    exp = exp / two;
    base = (base * base) % n;
  }

  let cHex = res.toString(16);
  if (cHex.length % 2 !== 0) {
    cHex = "0" + cHex;
  }
  const targetHexLen = k * 2;
  while (cHex.length < targetHexLen) {
    cHex = "0" + cHex;
  }

  return Buffer.from(cHex, "hex").toString("base64");
}
