import { pgTable, serial, text, integer, timestamp, jsonb, boolean } from "drizzle-orm/pg-core";

export const checkRuns = pgTable("check_runs", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  mode: text("mode").notNull().default("live"),
  totalCombos: integer("total_combos").notNull().default(0),
  hitCount: integer("hit_count").notNull().default(0),
  twoFaCount: integer("two_fa_count").notNull().default(0),
  faCount: integer("fa_count").notNull().default(0),
  freeCount: integer("free_count").notNull().default(0),
  badCount: integer("bad_count").notNull().default(0),
  banCount: integer("ban_count").notNull().default(0),
  errCount: integer("err_count").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const checkResults = pgTable("check_results", {
  id: serial("id").primaryKey(),
  runId: integer("run_id").references(() => checkRuns.id, { onDelete: "cascade" }),
  combo: text("combo").notNull(),
  username: text("username").notNull(),
  password: text("password").notNull(),
  status: text("status").notNull(), // 'hit', '2fa', 'free', 'bad', 'ban', 'err'
  steamId: text("steam_id"),
  level: text("level"),
  gamesCount: integer("games_count").default(0),
  walletBalance: text("wallet_balance"),
  country: text("country"),
  countryCode: text("country_code"),
  gameList: jsonb("game_list").$type<string[]>(),
  twoFactorTypes: text("two_factor_types"),
  info: text("info"),
  fa: boolean("fa"),
  activeSessions: integer("active_sessions"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export type CheckRun = typeof checkRuns.$inferSelect;
export type NewCheckRun = typeof checkRuns.$inferInsert;
export const weeklyLicenses = pgTable("weekly_licenses", {
  id: serial("id").primaryKey(),
  weekKey: text("week_key").notNull().unique(),
  licenseCode: text("license_code").notNull(),
  licenseHash: text("license_hash").notNull(),
  webhookSentAt: timestamp("webhook_sent_at", { withTimezone: true }),
  webhookClaimedAt: timestamp("webhook_claimed_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export type CheckResult = typeof checkResults.$inferSelect;
export type NewCheckResult = typeof checkResults.$inferInsert;
export type WeeklyLicense = typeof weeklyLicenses.$inferSelect;
export type NewWeeklyLicense = typeof weeklyLicenses.$inferInsert;
