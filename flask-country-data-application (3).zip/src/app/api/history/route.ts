import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { checkRuns, checkResults } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { requestHasValidLicense } from "@/lib/license";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    if (!(await requestHasValidLicense(req))) {
      return NextResponse.json({ error: "A valid weekly license key is required." }, { status: 403 });
    }

    const { searchParams } = new URL(req.url);
    const runIdParam = searchParams.get("runId");

    if (runIdParam) {
      const runId = parseInt(runIdParam, 10);
      const results = await db
        .select()
        .from(checkResults)
        .where(eq(checkResults.runId, runId))
        .orderBy(desc(checkResults.id));

      return NextResponse.json({ results });
    }

    const runs = await db
      .select()
      .from(checkRuns)
      .orderBy(desc(checkRuns.createdAt))
      .limit(50);

    // Also get the most recent hits across all runs
    const recentHits = await db
      .select()
      .from(checkResults)
      .where(eq(checkResults.status, "hit"))
      .orderBy(desc(checkResults.id))
      .limit(50);

    return NextResponse.json({ runs, recentHits });
  } catch (error: any) {
    console.error("History GET error:", error);
    return NextResponse.json({ error: error?.message || "Failed to fetch history" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    if (!(await requestHasValidLicense(req))) {
      return NextResponse.json({ error: "A valid weekly license key is required." }, { status: 403 });
    }

    const { searchParams } = new URL(req.url);
    const runIdParam = searchParams.get("runId");

    if (runIdParam) {
      const runId = parseInt(runIdParam, 10);
      await db.delete(checkResults).where(eq(checkResults.runId, runId));
      await db.delete(checkRuns).where(eq(checkRuns.id, runId));
      return NextResponse.json({ success: true, deletedRunId: runId });
    }

    // Clear all history
    await db.delete(checkResults);
    await db.delete(checkRuns);
    return NextResponse.json({ success: true, message: "All history cleared" });
  } catch (error: any) {
    console.error("History DELETE error:", error);
    return NextResponse.json({ error: error?.message || "Failed to clear history" }, { status: 500 });
  }
}
