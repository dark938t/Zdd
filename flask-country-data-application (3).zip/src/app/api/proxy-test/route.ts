import { NextRequest, NextResponse } from "next/server";
import fetch from "node-fetch";
import { HttpsProxyAgent } from "https-proxy-agent";
import { SocksProxyAgent } from "socks-proxy-agent";
import { requestHasValidLicense } from "@/lib/license";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    if (!(await requestHasValidLicense(req))) {
      return NextResponse.json({ error: "A valid weekly license key is required." }, { status: 403 });
    }

    const { proxies } = await req.json();
    if (!Array.isArray(proxies) || proxies.length === 0) {
      return NextResponse.json({ error: "No proxies provided" }, { status: 400 });
    }

    const testList = proxies.slice(0, 15); // test up to 15 at a time
    const results = await Promise.all(
      testList.map(async (raw: string) => {
        const p = (raw || "").trim();
        if (!p) return null;

        let url = p;
        if (!url.startsWith("http://") && !url.startsWith("https://") && !url.startsWith("socks4://") && !url.startsWith("socks5://")) {
          const parts = url.split(":");
          if (parts.length === 4) {
            url = `http://${parts[2]}:${parts[3]}@${parts[0]}:${parts[1]}`;
          } else {
            url = `http://${url}`;
          }
        }

        const agent = url.startsWith("socks4://") || url.startsWith("socks5://")
          ? new SocksProxyAgent(url)
          : new HttpsProxyAgent(url);

        const start = Date.now();
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 8000);

        try {
          const res = await fetch("https://api.steampowered.com/ISteamWebAPIUtil/GetServerInfo/v1/", {
            // @ts-ignore
            agent,
            signal: controller.signal as any,
            headers: {
              "User-Agent": "okhttp/4.9.2",
            },
          });
          const latency = Date.now() - start;
          clearTimeout(timer);
          return {
            proxy: p,
            alive: res.ok,
            status: res.status,
            latency,
          };
        } catch (err: any) {
          clearTimeout(timer);
          return {
            proxy: p,
            alive: false,
            latency: Date.now() - start,
            error: err.message?.includes("aborted") ? "Timeout (8s)" : (err.message || "Failed").slice(0, 40),
          };
        }
      })
    );

    return NextResponse.json({ results: results.filter(Boolean) });
  } catch (error: any) {
    return NextResponse.json({ error: error?.message || "Proxy test failed" }, { status: 500 });
  }
}
