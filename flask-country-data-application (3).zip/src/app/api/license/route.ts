import { NextRequest, NextResponse } from "next/server";
import {
  getOrCreateWeeklyLicense,
  licenseCookieName,
  licenseHashForCookie,
  validateWeeklyLicense,
  currentWeekKey,
} from "@/lib/license";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    const license = await getOrCreateWeeklyLicense();
    const cookieValue = request.cookies.get(licenseCookieName())?.value || "";
    const active = Boolean(cookieValue) && cookieValue === license.licenseHash;
    const configured = Boolean(process.env.DISCORD_LICENSE_WEBHOOK);

    return NextResponse.json({
      active: configured ? active : true,
      configured,
      requiresLicense: configured,
      weekKey: currentWeekKey(),
    });
  } catch (error: any) {
    console.error("License status error:", error);
    return NextResponse.json(
      { error: error?.message || "License service unavailable" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json().catch(() => ({}));
    const code = String(body.code || "").trim().toUpperCase();
    const configured = Boolean(process.env.DISCORD_LICENSE_WEBHOOK);

    if (!code) {
      return NextResponse.json({ valid: false, error: "Enter your weekly license key." }, { status: 400 });
    }

    const valid = await validateWeeklyLicense(code);
    if (!valid) {
      return NextResponse.json(
        { valid: false, error: "That license key is invalid or expired. Ask for the current weekly key." },
        { status: 401 }
      );
    }

    const response = NextResponse.json({ valid: true, configured });
    response.cookies.set({
      name: licenseCookieName(),
      value: licenseHashForCookie(code),
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      maxAge: 60 * 60 * 24 * 8,
      path: "/",
    });
    return response;
  } catch (error: any) {
    console.error("License validation error:", error);
    return NextResponse.json(
      { valid: false, error: error?.message || "License validation failed" },
      { status: 500 }
    );
  }
}
