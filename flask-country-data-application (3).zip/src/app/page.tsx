"use client";

import React, { useState, useEffect, useRef } from "react";
import confetti from "canvas-confetti";
import {
  Play,
  Square,
  RotateCcw,
  Upload,
  FileText,
  Sparkles,
  Shield,
  Layers,
  Cpu,
  Download,
  Copy,
  Trash2,
  Terminal,
  Settings,
  HelpCircle,
  Flame,
  CheckCircle2,
  Globe,
  Sliders,
  AlertTriangle,
} from "lucide-react";
import { Navbar } from "@/components/Navbar";
import { StatsGrid } from "@/components/StatsGrid";
import { ResultsView } from "@/components/ResultsView";
import { AccountModal } from "@/components/AccountModal";
import { ComboTools } from "@/components/ComboTools";
import { ProxyTester } from "@/components/ProxyTester";
import { HitsVault } from "@/components/HitsVault";
import { LicenseGate } from "@/components/LicenseGate";
import { CheckStats, ComboResultItem } from "@/lib/steam/constants";
import { SAMPLE_COMBOS_TEXT } from "@/lib/steam/demoData";
import { soundEngine } from "@/lib/audio";

export default function SteamCheckerApp() {
  const [activeTab, setActiveTab] = useState<"checker" | "vault" | "tools" | "proxies">("checker");
  const [demoMode, setDemoMode] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(false);

  // Input states
  const [combosText, setCombosText] = useState<string>("");
  const [proxiesText, setProxiesText] = useState<string>("");
  const [threads, setThreads] = useState<number>(10);
  const [retries, setRetries] = useState<number>(2);

  // Runtime states
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [stats, setStats] = useState<CheckStats>({
    done: 0,
    hit: 0,
    "2fa": 0,
    free: 0,
    bad: 0,
    ban: 0,
    err: 0,
    fa: 0,
  });
  const [results, setResults] = useState<ComboResultItem[]>([]);
  const [activeFilter, setActiveFilter] = useState<string>("all");
  const [selectedInspect, setSelectedInspect] = useState<ComboResultItem | null>(null);
  const [cpm, setCpm] = useState<number>(0);
  const [copiedHitsNotice, setCopiedHitsNotice] = useState<boolean>(false);
  const [runError, setRunError] = useState<string>("");

  // Refs for tracking runtime and abort
  const abortControllerRef = useRef<AbortController | null>(null);
  const startTimeRef = useRef<number>(0);
  const checkCountRef = useRef<number>(0);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Calculate parsed combos count
  const validCombosCount = combosText
    .split("\n")
    .map((l) => l.trim())
    .filter((l) => l.includes(":")).length;

  const validProxiesCount = proxiesText
    .split("\n")
    .map((l) => l.trim())
    .filter(Boolean).length;

  // Handle Confetti
  const triggerConfetti = () => {
    if (typeof window === "undefined") return;
    try {
      confetti({
        particleCount: 45,
        spread: 60,
        origin: { y: 0.8 },
        colors: ["#10b981", "#38bdf8", "#fbbf24", "#a855f7"],
      });
    } catch {
      // ignore
    }
  };

  // Start Checking
  const handleStart = async () => {
    soundEngine.playClick();
    const rawLines = combosText
      .split("\n")
      .map((x) => x.trim())
      .filter((x) => x.includes(":"));

    if (rawLines.length === 0) {
      alert("Please provide at least one credential pair in username:password format.");
      return;
    }

    const proxyLines = proxiesText
      .split("\n")
      .map((x) => x.trim())
      .filter(Boolean);

    // Reset stats & states
    setIsRunning(true);
    setRunError("");
    setStats({ done: 0, hit: 0, "2fa": 0, free: 0, bad: 0, ban: 0, err: 0, fa: 0 });
    setResults([]);
    startTimeRef.current = Date.now();
    checkCountRef.current = 0;
    setCpm(0);

    const controller = new AbortController();
    abortControllerRef.current = controller;

    try {
      const response = await fetch("/api/check", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        signal: controller.signal,
        body: JSON.stringify({
          combos: rawLines,
          proxies: proxyLines,
          threads,
          retries,
          mode: demoMode ? "demo" : "live",
          stream: true,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `HTTP ${response.status}`);
      }

      if (!response.body) {
        throw new Error("No response body stream");
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n\n");
        buffer = lines.pop() || "";

        for (const block of lines) {
          const trimmed = block.trim();
          if (trimmed.startsWith("data: ")) {
            try {
              const data = JSON.parse(trimmed.slice(6));

              if (data.type === "item") {
                const item: ComboResultItem = data.item;
                const newStats: CheckStats = data.stats;

                checkCountRef.current++;
                const elapsedMin = (Date.now() - startTimeRef.current) / 60000;
                if (elapsedMin > 0) {
                  setCpm(Math.round(checkCountRef.current / elapsedMin));
                }

                setStats(newStats);
                setResults((prev) => [item, ...prev]);

                // Audio & visual effect cues
                if (item.result.st === "hit") {
                  soundEngine.playHit();
                  triggerConfetti();
                } else if (item.result.st === "2fa") {
                  soundEngine.play2FA();
                }
              } else if (data.type === "done") {
                soundEngine.playComplete();
                setStats(data.stats);
              }
            } catch (jsonErr) {
              // Ignore malformed chunks
            }
          }
        }
      }
    } catch (err: any) {
      if (err.name !== "AbortError") {
        console.error("Check process error:", err);
        const msg = String(err?.message || err);
        if (msg.includes("403") || msg.includes("license")) {
          setRunError("License required — enter your weekly key to unlock the checker.");
        } else if (msg.includes("Failed to fetch") || msg.includes("NetworkError")) {
          setRunError("Cannot reach the server. Check your connection and try again.");
        } else if (msg.includes("429") || msg.includes("rate limit")) {
          setRunError("Steam rate-limited the request. Reduce threads and retry.");
        } else {
          setRunError(`Check failed: ${msg.slice(0, 120)}`);
        }
      }
    } finally {
      setIsRunning(false);
      abortControllerRef.current = null;
    }
  };

  // Stop Checking
  const handleStop = () => {
    soundEngine.playClick();
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setIsRunning(false);
  };

  // Clear Results
  const handleClear = () => {
    soundEngine.playClick();
    setResults([]);
    setStats({ done: 0, hit: 0, "2fa": 0, free: 0, bad: 0, ban: 0, err: 0, fa: 0 });
    setCpm(0);
  };

  // File Upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        setCombosText(content);
        soundEngine.playClick();
      }
    };
    reader.readAsText(file);
    e.target.value = "";
  };

  // Load Preset Demo Combos (sample data — only meaningful in Demo/Preview mode)
  const loadDemoCombos = () => {
    soundEngine.playClick();
    setCombosText(SAMPLE_COMBOS_TEXT);
    setDemoMode(true);
  };

  // Format the owned-games list for text output
  const formatGamesLine = (r: ComboResultItem["result"]) => {
    const games = r.game_list || [];
    if (games.length === 0) return "None";
    return games.join(", ");
  };

  // Copy All Hits
  const handleCopyAllHits = () => {
    soundEngine.playClick();
    const hits = results.filter((r) => r.result.st === "hit");
    if (hits.length === 0) return;

    const lines = hits.map((h) => {
      const r = h.result;
      const faTag = r.fa ? " | FA" : "";
      const sessions = r.activeSessions !== undefined ? ` | Sessions:${r.activeSessions}` : "";
      return (
        `${h.combo} | ID:${r.sid || "N/A"} | Lv:${r.level || "0"} | Games:${r.games || 0} | Wallet:${r.balance || "N/A"} | ${r.country || r.cc || "N/A"}${sessions}${faTag}\n` +
        `  Games: ${formatGamesLine(r)}`
      );
    });

    navigator.clipboard.writeText(lines.join("\n"));
    setCopiedHitsNotice(true);
    setTimeout(() => setCopiedHitsNotice(false), 2000);
  };

  // Export TXT
  const handleExportTxt = () => {
    soundEngine.playClick();
    let text = "";
    results.forEach((x) => {
      const r = x.result;
      if (r.st === "hit") {
        const faTag = r.fa ? " | FA" : "";
        const sessions = r.activeSessions !== undefined ? ` | Sessions:${r.activeSessions}` : "";
        text += `[HIT] ${x.combo} | SteamID:${r.sid || "N/A"} | Level:${r.level || "0"} | Games:${r.games || 0} | Wallet:${r.balance || "N/A"} | Country:${r.country || r.cc || "N/A"}${sessions}${faTag}\n`;
        text += `  Games: ${formatGamesLine(r)}\n`;
        if (r.sessionDetails && r.sessionDetails.length > 0) {
          text += `  Active sessions: ${r.sessionDetails.join(" | ")}\n`;
        }
      } else if (r.st === "2fa") {
        text += `[2FA] ${x.combo} | SteamID:${r.sid || "N/A"} | Types:${r.types || "N/A"}\n`;
      } else if (r.st === "free") {
        text += `[FREE] ${x.combo} | SteamID:${r.sid || "N/A"} | Level:${r.level || "0"} | Country:${r.country || "N/A"}\n`;
        text += `  Games: ${formatGamesLine(r)}\n`;
      } else if (r.st === "bad") {
        text += `[BAD] ${x.combo}\n`;
      } else if (r.st === "ban") {
        text += `[BAN] ${x.combo}\n`;
      } else {
        text += `[ERR] ${x.combo} | ${r.info || "N/A"}\n`;
      }
    });

    const blob = new Blob([text], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `steam_checker_results_${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Export JSON
  const handleExportJson = () => {
    soundEngine.playClick();
    const blob = new Blob([JSON.stringify(results, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `steam_checker_results_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Export CSV
  const handleExportCsv = () => {
    soundEngine.playClick();
    let csv = "Status,Combo,SteamID,Level,GamesCount,Wallet,Country,Sessions,FA,GamesList,Info\n";
    results.forEach((x) => {
      const r = x.result;
      const cleanCombo = `"${x.combo.replace(/"/g, '""')}"`;
      const cleanInfo = `"${(r.info || "").replace(/"/g, '""')}"`;
      const cleanGames = `"${(r.game_list || []).join("; ").replace(/"/g, '""')}"`;
      const faValue = r.fa === true ? "YES" : r.fa === false ? "NO" : "";
      const sessionsValue = r.activeSessions !== undefined ? String(r.activeSessions) : "";
      csv += `${r.st},${cleanCombo},${r.sid || ""},${r.level || ""},${r.games || 0},"${r.balance || ""}","${r.country || r.cc || ""}",${sessionsValue},${faValue},${cleanGames},${cleanInfo}\n`;
    });

    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `steam_checker_results_${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <LicenseGate>
      <div className="min-h-screen bg-[#080c14] text-slate-100 scanline-bg">
      {/* Navbar with Mode switcher & Sound toggle */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        demoMode={demoMode}
        setDemoMode={setDemoMode}
        isMuted={isMuted}
        setIsMuted={setIsMuted}
        isRunning={isRunning}
      />

      {/* Main Content Area */}
      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6">
        {/* Banner notification for Demo vs Live */}
        {demoMode && activeTab === "checker" && (
          <div className="mb-4 flex items-center justify-between gap-3 rounded-xl border border-amber-500/30 bg-amber-950/30 px-4 py-2.5 text-xs text-amber-200">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 shrink-0 text-amber-400" />
              <span>
                <strong>UI Preview Mode:</strong> Only the 12 built-in sample accounts below produce demo data. Any other credentials return a &quot;no sample data&quot; notice — they are <strong>not</strong> real checks. For 100% real Steam results, switch to <strong>Live Steam</strong>.
              </span>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={loadDemoCombos}
                className="rounded-lg border border-amber-500/30 bg-amber-500/10 px-2.5 py-1 font-semibold text-amber-300 hover:bg-amber-500/20 transition"
              >
                Load Sample Combos
              </button>
              <button
                onClick={() => setDemoMode(false)}
                className="font-bold text-amber-300 underline hover:text-amber-100"
              >
                Switch to Live
              </button>
            </div>
          </div>
        )}

        {/* Tab 1: Live Checker */}
        {activeTab === "checker" && (
          <div className="space-y-4">
            {/* Combos & Proxies Dual Input Deck */}
            <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
              {/* Combos Card */}
              <div className="rounded-2xl border border-slate-800/80 bg-slate-900/60 p-4 backdrop-blur-md">
                <div className="flex items-center justify-between pb-2.5">
                  <div className="flex items-center gap-2">
                    <FileText className="h-4 w-4 text-sky-400" />
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                      Combos Input
                    </span>
                    <span className="rounded-md border border-slate-800 bg-slate-950 px-2 py-0.5 font-mono text-[11px] text-sky-400">
                      {validCombosCount} pairs
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5 text-xs">
                    <button
                      onClick={loadDemoCombos}
                      className="rounded-lg border border-slate-800 bg-slate-950 px-2.5 py-1 text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition"
                      title="Insert demo sample list"
                    >
                      Sample
                    </button>

                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="flex items-center gap-1 rounded-lg border border-slate-800 bg-slate-950 px-2.5 py-1 text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition"
                      title="Upload .txt combo list"
                    >
                      <Upload className="h-3 w-3" />
                      <span>Upload</span>
                    </button>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept=".txt"
                      className="hidden"
                      onChange={handleFileUpload}
                    />

                    <button
                      onClick={() => setCombosText("")}
                      className="rounded-lg border border-slate-800 bg-slate-950 px-2 py-1 text-slate-400 hover:text-rose-400 transition"
                    >
                      Clear
                    </button>
                  </div>
                </div>

                <textarea
                  rows={9}
                  spellCheck={false}
                  value={combosText}
                  onChange={(e) => setCombosText(e.target.value)}
                  placeholder={`username:password\nanother_account:pass123\nsteam_user:secretPass`}
                  className="w-full resize-y rounded-xl border border-slate-800/80 bg-slate-950/80 p-3 font-mono text-xs leading-relaxed text-slate-200 placeholder-slate-600 focus:border-sky-500 focus:outline-none"
                />
                <div className="mt-1 flex items-center justify-between text-[11px] text-slate-500">
                  <span>Format: username:password (one per line)</span>
                  <span>UTF-8 Monospace</span>
                </div>
              </div>

              {/* Proxies Card */}
              <div className="rounded-2xl border border-slate-800/80 bg-slate-900/60 p-4 backdrop-blur-md">
                <div className="flex items-center justify-between pb-2.5">
                  <div className="flex items-center gap-2">
                    <Globe className="h-4 w-4 text-emerald-400" />
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                      Proxies <span className="text-slate-500 font-normal">(Optional)</span>
                    </span>
                    <span className="rounded-md border border-slate-800 bg-slate-950 px-2 py-0.5 font-mono text-[11px] text-emerald-400">
                      {validProxiesCount} loaded
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5 text-xs">
                    <button
                      onClick={() => setActiveTab("proxies")}
                      className="rounded-lg border border-slate-800 bg-slate-950 px-2.5 py-1 text-slate-400 hover:text-sky-300 hover:bg-slate-800 transition"
                    >
                      Test Proxies
                    </button>
                    <button
                      onClick={() => setProxiesText("")}
                      className="rounded-lg border border-slate-800 bg-slate-950 px-2 py-1 text-slate-400 hover:text-rose-400 transition"
                    >
                      Clear
                    </button>
                  </div>
                </div>

                <textarea
                  rows={9}
                  spellCheck={false}
                  value={proxiesText}
                  onChange={(e) => setProxiesText(e.target.value)}
                  placeholder={`127.0.0.1:8080\nhttp://username:password@1.2.3.4:3128\nsocks5://127.0.0.1:1080`}
                  className="w-full resize-y rounded-xl border border-slate-800/80 bg-slate-950/80 p-3 font-mono text-xs leading-relaxed text-slate-200 placeholder-slate-600 focus:border-sky-500 focus:outline-none"
                />
                <div className="mt-1 flex items-center justify-between text-[11px] text-slate-500">
                  <span>Supports HTTP, HTTPS, SOCKS4, SOCKS5</span>
                  <span>Auto-rotating pool</span>
                </div>
              </div>
            </div>

            {/* Execution Control Dock */}
            <div className="rounded-2xl border border-slate-800/80 bg-slate-900/80 p-4 backdrop-blur-md">
              <div className="flex flex-wrap items-center justify-between gap-4">
                {/* Sliders & Parameters */}
                <div className="flex flex-wrap items-center gap-6">
                  {/* Threads Slider */}
                  <div className="flex items-center gap-3">
                    <Sliders className="h-4 w-4 text-sky-400" />
                    <div>
                      <div className="flex items-center justify-between gap-4 text-xs font-semibold text-slate-300">
                        <span>Threads</span>
                        <span className="font-mono text-sky-400">{threads}</span>
                      </div>
                      <input
                        type="range"
                        min="1"
                        max="50"
                        value={threads}
                        onChange={(e) => setThreads(parseInt(e.target.value, 10))}
                        disabled={isRunning}
                        className="mt-1 h-1.5 w-32 cursor-pointer accent-sky-400 disabled:opacity-40"
                      />
                    </div>
                  </div>

                  {/* Retries */}
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-400">Retries:</span>
                    <select
                      value={retries}
                      onChange={(e) => setRetries(parseInt(e.target.value, 10))}
                      disabled={isRunning}
                      className="rounded-lg border border-slate-800 bg-slate-950 px-2.5 py-1 text-xs text-slate-200 focus:outline-none"
                    >
                      <option value="0">0 (Fast)</option>
                      <option value="1">1 (Standard)</option>
                      <option value="2">2 (Thorough)</option>
                    </select>
                  </div>
                </div>

                {/* Primary Action Buttons */}
                <div className="flex items-center gap-3">
                  {!isRunning ? (
                    <button
                      onClick={handleStart}
                      disabled={validCombosCount === 0}
                      className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-emerald-500 via-teal-500 to-sky-500 px-6 py-2.5 text-xs font-bold text-slate-950 shadow-lg shadow-emerald-500/25 transition duration-200 hover:brightness-110 active:scale-95 disabled:cursor-not-allowed disabled:opacity-40"
                    >
                      <Play className="h-4 w-4 fill-current" />
                      <span>START CHECKING</span>
                    </button>
                  ) : (
                    <button
                      onClick={handleStop}
                      className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 px-6 py-2.5 text-xs font-bold text-white shadow-lg shadow-rose-600/30 transition hover:brightness-110 active:scale-95"
                    >
                      <Square className="h-4 w-4 fill-current" />
                      <span>STOP CHECK</span>
                    </button>
                  )}

                  <button
                    onClick={handleClear}
                    disabled={isRunning || results.length === 0}
                    className="flex items-center gap-1.5 rounded-xl border border-slate-800 bg-slate-950 px-3.5 py-2.5 text-xs font-semibold text-slate-400 transition hover:border-slate-700 hover:text-slate-200 disabled:opacity-40"
                  >
                    <RotateCcw className="h-3.5 w-3.5" />
                    <span>Reset</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Real-time Analytics & Counters */}
            <StatsGrid
              stats={stats}
              totalCombos={validCombosCount}
              activeFilter={activeFilter}
              setActiveFilter={setActiveFilter}
              cpm={cpm}
              isRunning={isRunning}
            />

            {/* Visible run error banner */}
            {runError && (
              <div className="flex items-center justify-between gap-3 rounded-xl border border-rose-500/30 bg-rose-950/30 px-4 py-3 text-xs text-rose-300">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 shrink-0 text-rose-400" />
                  <span>{runError}</span>
                </div>
                <button
                  onClick={() => setRunError("")}
                  className="shrink-0 rounded-lg border border-rose-500/30 bg-rose-500/10 px-2.5 py-1 font-semibold text-rose-300 hover:bg-rose-500/20 transition"
                >
                  Dismiss
                </button>
              </div>
            )}

            {/* Results Grid / Terminal */}
            <ResultsView
              results={results}
              activeFilter={activeFilter}
              setActiveFilter={setActiveFilter}
              onInspect={(item) => setSelectedInspect(item)}
              onClear={handleClear}
              onExportTxt={handleExportTxt}
              onExportJson={handleExportJson}
              onExportCsv={handleExportCsv}
              onCopyAllHits={handleCopyAllHits}
              copiedHitsNotice={copiedHitsNotice}
              isRunning={isRunning}
            />
          </div>
        )}

        {/* Tab 2: PostgreSQL Hits Vault */}
        {activeTab === "vault" && (
          <HitsVault onInspect={(item) => setSelectedInspect(item)} />
        )}

        {/* Tab 3: Combo Tools Suite */}
        {activeTab === "tools" && (
          <ComboTools
            onApplyCombos={(combos) => {
              setCombosText(combos);
              setActiveTab("checker");
            }}
          />
        )}

        {/* Tab 4: Proxy Tester */}
        {activeTab === "proxies" && (
          <ProxyTester
            initialProxies={proxiesText}
            onApplyProxies={(proxies) => {
              setProxiesText(proxies);
              setActiveTab("checker");
            }}
          />
        )}
      </main>

      {/* Account Inspector Modal */}
      {selectedInspect && (
        <AccountModal
          item={selectedInspect}
          onClose={() => setSelectedInspect(null)}
        />
      )}
      </div>
    </LicenseGate>
  );
}
