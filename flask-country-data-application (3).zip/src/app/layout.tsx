import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Steam Engine // High-Speed Account Checker & Vault",
  description: "Advanced Steam account audit suite with multi-threaded verification, real-time live telemetry, games library inspector, proxy rotation, and encrypted vault storage.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-[#080c14] text-slate-100 antialiased min-h-screen selection:bg-sky-500/30 selection:text-sky-200">
        {children}
      </body>
    </html>
  );
}
